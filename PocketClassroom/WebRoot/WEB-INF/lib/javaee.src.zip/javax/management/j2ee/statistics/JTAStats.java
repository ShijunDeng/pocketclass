package javax.management.j2ee.statistics;

public abstract interface JTAStats extends Stats
{
  public abstract CountStatistic getActiveCount();

  public abstract CountStatistic getCommittedCount();

  public abstract CountStatistic getRolledbackCount();
}