package javax.management.j2ee.statistics;

public abstract interface URLStats extends Stats
{
}