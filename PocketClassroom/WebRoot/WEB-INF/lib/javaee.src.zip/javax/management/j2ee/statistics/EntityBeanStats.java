package javax.management.j2ee.statistics;

public abstract interface EntityBeanStats extends EJBStats
{
  public abstract RangeStatistic getReadyCount();

  public abstract RangeStatistic getPooledCount();
}