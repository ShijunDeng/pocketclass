package javax.management.j2ee.statistics;

public abstract interface EJBStats extends Stats
{
  public abstract CountStatistic getCreateCount();

  public abstract CountStatistic getRemoveCount();
}