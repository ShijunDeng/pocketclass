package javax.management.j2ee.statistics;

public abstract interface StatelessSessionBeanStats extends SessionBeanStats
{
}