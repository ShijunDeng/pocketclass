package javax.management.j2ee.statistics;

public abstract interface JavaMailStats
{
  public abstract CountStatistic getSentMailCount();
}