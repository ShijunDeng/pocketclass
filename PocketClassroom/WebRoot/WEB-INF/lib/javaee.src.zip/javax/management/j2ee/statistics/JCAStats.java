package javax.management.j2ee.statistics;

public abstract interface JCAStats extends Stats
{
  public abstract JCAConnectionStats[] getConnections();

  public abstract JCAConnectionPoolStats[] getConnectionPools();
}