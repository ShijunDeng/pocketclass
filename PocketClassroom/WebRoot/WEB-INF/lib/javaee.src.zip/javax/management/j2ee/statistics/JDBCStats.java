package javax.management.j2ee.statistics;

public abstract interface JDBCStats extends Stats
{
  public abstract JDBCConnectionStats[] getConnections();

  public abstract JDBCConnectionPoolStats[] getConnectionPools();
}