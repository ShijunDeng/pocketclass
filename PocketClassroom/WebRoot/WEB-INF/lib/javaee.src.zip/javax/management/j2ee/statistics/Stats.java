package javax.management.j2ee.statistics;

public abstract interface Stats
{
  public abstract Statistic getStatistic(String paramString);

  public abstract String[] getStatisticNames();

  public abstract Statistic[] getStatistics();
}