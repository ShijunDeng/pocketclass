package javax.management.j2ee.statistics;

public abstract interface JMSProducerStats extends JMSEndpointStats
{
  public abstract String getDestination();
}