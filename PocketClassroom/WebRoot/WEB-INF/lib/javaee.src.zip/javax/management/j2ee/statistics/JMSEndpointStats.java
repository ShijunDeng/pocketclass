package javax.management.j2ee.statistics;

public abstract interface JMSEndpointStats extends Stats
{
  public abstract CountStatistic getMessageCount();

  public abstract CountStatistic getPendingMessageCount();

  public abstract CountStatistic getExpiredMessageCount();

  public abstract TimeStatistic getMessageWaitTime();
}