package javax.management.j2ee.statistics;

public abstract interface SessionBeanStats extends EJBStats
{
  public abstract RangeStatistic getMethodReadyCount();
}