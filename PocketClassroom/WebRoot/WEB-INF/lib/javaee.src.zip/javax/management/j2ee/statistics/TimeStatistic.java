package javax.management.j2ee.statistics;

public abstract interface TimeStatistic extends Statistic
{
  public abstract long getCount();

  public abstract long getMaxTime();

  public abstract long getMinTime();

  public abstract long getTotalTime();
}