package javax.management.j2ee.statistics;

public abstract interface JVMStats extends Stats
{
  public abstract CountStatistic getUpTime();

  public abstract BoundedRangeStatistic getHeapSize();
}