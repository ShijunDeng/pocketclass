package javax.management.j2ee.statistics;

public abstract interface JMSConsumerStats extends JMSEndpointStats
{
  public abstract String getOrigin();
}