package javax.management.j2ee.statistics;

public abstract interface BoundaryStatistic extends Statistic
{
  public abstract long getUpperBound();

  public abstract long getLowerBound();
}