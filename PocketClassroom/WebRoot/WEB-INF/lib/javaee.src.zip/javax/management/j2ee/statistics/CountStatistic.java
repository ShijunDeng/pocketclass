package javax.management.j2ee.statistics;

public abstract interface CountStatistic extends Statistic
{
  public abstract long getCount();
}