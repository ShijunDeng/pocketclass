package javax.management.j2ee.statistics;

public abstract interface MessageDrivenBeanStats extends EJBStats
{
  public abstract CountStatistic getMessageCount();
}