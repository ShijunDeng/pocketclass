package javax.management.j2ee.statistics;

public abstract interface JCAConnectionStats extends Stats
{
  public abstract String getConnectionFactory();

  public abstract String getManagedConnectionFactory();

  public abstract TimeStatistic getWaitTime();

  public abstract TimeStatistic getUseTime();
}