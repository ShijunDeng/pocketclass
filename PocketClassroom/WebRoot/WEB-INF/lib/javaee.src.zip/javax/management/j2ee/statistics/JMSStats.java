package javax.management.j2ee.statistics;

public abstract interface JMSStats extends Stats
{
  public abstract JMSConnectionStats[] getConnections();
}