package javax.management.j2ee.statistics;

public abstract interface BoundedRangeStatistic extends BoundaryStatistic, RangeStatistic
{
}