package javax.management.j2ee.statistics;

public abstract interface JDBCConnectionPoolStats extends JDBCConnectionStats
{
  public abstract CountStatistic getCreateCount();

  public abstract CountStatistic getCloseCount();

  public abstract BoundedRangeStatistic getPoolSize();

  public abstract BoundedRangeStatistic getFreePoolSize();

  public abstract RangeStatistic getWaitingThreadCount();
}