package javax.management.j2ee.statistics;

public abstract interface Statistic
{
  public abstract String getName();

  public abstract String getUnit();

  public abstract String getDescription();

  public abstract long getStartTime();

  public abstract long getLastSampleTime();
}