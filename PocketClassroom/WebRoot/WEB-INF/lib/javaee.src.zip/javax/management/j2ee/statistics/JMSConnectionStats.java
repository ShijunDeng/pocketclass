package javax.management.j2ee.statistics;

public abstract interface JMSConnectionStats extends Stats
{
  public abstract JMSSessionStats[] getSessions();

  public abstract boolean isTransactional();
}