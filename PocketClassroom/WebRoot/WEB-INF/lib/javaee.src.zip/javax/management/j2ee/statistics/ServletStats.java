package javax.management.j2ee.statistics;

public abstract interface ServletStats extends Stats
{
  public abstract TimeStatistic getServiceTime();
}