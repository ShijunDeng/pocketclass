package javax.management.j2ee.statistics;

public abstract interface StatefulSessionBeanStats extends SessionBeanStats
{
  public abstract RangeStatistic getPassiveCount();
}