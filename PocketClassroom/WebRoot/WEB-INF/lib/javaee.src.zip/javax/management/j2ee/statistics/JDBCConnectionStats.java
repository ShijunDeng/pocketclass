package javax.management.j2ee.statistics;

public abstract interface JDBCConnectionStats extends Stats
{
  public abstract String getJdbcDataSource();

  public abstract TimeStatistic getWaitTime();

  public abstract TimeStatistic getUseTime();
}