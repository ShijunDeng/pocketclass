package javax.management.j2ee.statistics;

public abstract interface JMSSessionStats extends Stats
{
  public abstract JMSProducerStats[] getProducers();

  public abstract JMSConsumerStats[] getConsumers();

  public abstract CountStatistic getMessageCount();

  public abstract CountStatistic getPendingMessageCount();

  public abstract CountStatistic getExpiredMessageCount();

  public abstract TimeStatistic getMessageWaitTime();

  public abstract CountStatistic getDurableSubscriptionCount();
}