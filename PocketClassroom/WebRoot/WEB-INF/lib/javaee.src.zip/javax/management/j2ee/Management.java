package javax.management.j2ee;

import java.rmi.RemoteException;
import java.util.Set;
import javax.ejb.EJBObject;
import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.IntrospectionException;
import javax.management.InvalidAttributeValueException;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.ObjectName;
import javax.management.QueryExp;
import javax.management.ReflectionException;

public abstract interface Management extends EJBObject
{
  public abstract Set queryNames(ObjectName paramObjectName, QueryExp paramQueryExp)
    throws RemoteException;

  public abstract boolean isRegistered(ObjectName paramObjectName)
    throws RemoteException;

  public abstract Integer getMBeanCount()
    throws RemoteException;

  public abstract MBeanInfo getMBeanInfo(ObjectName paramObjectName)
    throws IntrospectionException, InstanceNotFoundException, ReflectionException, RemoteException;

  public abstract Object getAttribute(ObjectName paramObjectName, String paramString)
    throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException, RemoteException;

  public abstract AttributeList getAttributes(ObjectName paramObjectName, String[] paramArrayOfString)
    throws InstanceNotFoundException, ReflectionException, RemoteException;

  public abstract void setAttribute(ObjectName paramObjectName, Attribute paramAttribute)
    throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException, RemoteException;

  public abstract AttributeList setAttributes(ObjectName paramObjectName, AttributeList paramAttributeList)
    throws InstanceNotFoundException, ReflectionException, RemoteException;

  public abstract Object invoke(ObjectName paramObjectName, String paramString, Object[] paramArrayOfObject, String[] paramArrayOfString)
    throws InstanceNotFoundException, MBeanException, ReflectionException, RemoteException;

  public abstract String getDefaultDomain()
    throws RemoteException;

  public abstract ListenerRegistration getListenerRegistry()
    throws RemoteException;
}