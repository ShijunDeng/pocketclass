package javax.jms;

public abstract interface Destination
{
}