package javax.jms;

public class TransactionInProgressException extends JMSException
{
  public TransactionInProgressException(String reason, String errorCode)
  {
    super(reason, errorCode);
  }

  public TransactionInProgressException(String reason)
  {
    super(reason);
  }
}