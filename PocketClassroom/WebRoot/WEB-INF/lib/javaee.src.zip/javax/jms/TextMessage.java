package javax.jms;

public abstract interface TextMessage extends Message
{
  public abstract void setText(String paramString)
    throws JMSException;

  public abstract String getText()
    throws JMSException;
}