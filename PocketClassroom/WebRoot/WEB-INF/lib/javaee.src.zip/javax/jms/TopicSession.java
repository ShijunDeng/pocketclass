package javax.jms;

public abstract interface TopicSession extends Session
{
  public abstract Topic createTopic(String paramString)
    throws JMSException;

  public abstract TopicSubscriber createSubscriber(Topic paramTopic)
    throws JMSException;

  public abstract TopicSubscriber createSubscriber(Topic paramTopic, String paramString, boolean paramBoolean)
    throws JMSException;

  public abstract TopicSubscriber createDurableSubscriber(Topic paramTopic, String paramString)
    throws JMSException;

  public abstract TopicSubscriber createDurableSubscriber(Topic paramTopic, String paramString1, String paramString2, boolean paramBoolean)
    throws JMSException;

  public abstract TopicPublisher createPublisher(Topic paramTopic)
    throws JMSException;

  public abstract TemporaryTopic createTemporaryTopic()
    throws JMSException;

  public abstract void unsubscribe(String paramString)
    throws JMSException;
}