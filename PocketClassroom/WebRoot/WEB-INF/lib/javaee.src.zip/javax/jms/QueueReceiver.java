package javax.jms;

public abstract interface QueueReceiver extends MessageConsumer
{
  public abstract Queue getQueue()
    throws JMSException;
}