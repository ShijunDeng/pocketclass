package javax.jms;

public abstract interface XAQueueConnection extends XAConnection, QueueConnection
{
  public abstract XAQueueSession createXAQueueSession()
    throws JMSException;

  public abstract QueueSession createQueueSession(boolean paramBoolean, int paramInt)
    throws JMSException;
}