package javax.jms;

public abstract interface QueueConnection extends Connection
{
  public abstract QueueSession createQueueSession(boolean paramBoolean, int paramInt)
    throws JMSException;

  public abstract ConnectionConsumer createConnectionConsumer(Queue paramQueue, String paramString, ServerSessionPool paramServerSessionPool, int paramInt)
    throws JMSException;
}