package javax.jms;

public class JMSSecurityException extends JMSException
{
  public JMSSecurityException(String reason, String errorCode)
  {
    super(reason, errorCode);
  }

  public JMSSecurityException(String reason)
  {
    super(reason);
  }
}