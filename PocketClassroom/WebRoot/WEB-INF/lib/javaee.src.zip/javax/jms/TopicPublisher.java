package javax.jms;

public abstract interface TopicPublisher extends MessageProducer
{
  public abstract Topic getTopic()
    throws JMSException;

  public abstract void publish(Message paramMessage)
    throws JMSException;

  public abstract void publish(Message paramMessage, int paramInt1, int paramInt2, long paramLong)
    throws JMSException;

  public abstract void publish(Topic paramTopic, Message paramMessage)
    throws JMSException;

  public abstract void publish(Topic paramTopic, Message paramMessage, int paramInt1, int paramInt2, long paramLong)
    throws JMSException;
}