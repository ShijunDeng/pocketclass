package javax.jms;

public abstract interface Queue extends Destination
{
  public abstract String getQueueName()
    throws JMSException;

  public abstract String toString();
}