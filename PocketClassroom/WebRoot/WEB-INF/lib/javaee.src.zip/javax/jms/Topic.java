package javax.jms;

public abstract interface Topic extends Destination
{
  public abstract String getTopicName()
    throws JMSException;

  public abstract String toString();
}