package javax.jms;

public abstract interface MessageListener
{
  public abstract void onMessage(Message paramMessage);
}