package javax.jms;

public abstract interface XATopicConnectionFactory extends XAConnectionFactory, TopicConnectionFactory
{
  public abstract XATopicConnection createXATopicConnection()
    throws JMSException;

  public abstract XATopicConnection createXATopicConnection(String paramString1, String paramString2)
    throws JMSException;
}