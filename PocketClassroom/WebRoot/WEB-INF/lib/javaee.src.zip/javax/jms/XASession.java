package javax.jms;

import javax.transaction.xa.XAResource;

public abstract interface XASession extends Session
{
  public abstract Session getSession()
    throws JMSException;

  public abstract XAResource getXAResource();

  public abstract boolean getTransacted()
    throws JMSException;

  public abstract void commit()
    throws JMSException;

  public abstract void rollback()
    throws JMSException;
}