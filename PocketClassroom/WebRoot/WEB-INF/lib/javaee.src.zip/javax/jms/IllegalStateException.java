package javax.jms;

public class IllegalStateException extends JMSException
{
  public IllegalStateException(String reason, String errorCode)
  {
    super(reason, errorCode);
  }

  public IllegalStateException(String reason)
  {
    super(reason);
  }
}