package javax.jms;

public abstract interface XAConnection extends Connection
{
  public abstract XASession createXASession()
    throws JMSException;

  public abstract Session createSession(boolean paramBoolean, int paramInt)
    throws JMSException;
}