package javax.jms;

public abstract interface ExceptionListener
{
  public abstract void onException(JMSException paramJMSException);
}