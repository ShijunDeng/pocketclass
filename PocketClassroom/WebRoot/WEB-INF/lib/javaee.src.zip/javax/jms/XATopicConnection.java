package javax.jms;

public abstract interface XATopicConnection extends XAConnection, TopicConnection
{
  public abstract XATopicSession createXATopicSession()
    throws JMSException;

  public abstract TopicSession createTopicSession(boolean paramBoolean, int paramInt)
    throws JMSException;
}