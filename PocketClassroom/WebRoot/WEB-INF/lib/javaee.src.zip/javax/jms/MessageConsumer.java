package javax.jms;

public abstract interface MessageConsumer
{
  public abstract String getMessageSelector()
    throws JMSException;

  public abstract MessageListener getMessageListener()
    throws JMSException;

  public abstract void setMessageListener(MessageListener paramMessageListener)
    throws JMSException;

  public abstract Message receive()
    throws JMSException;

  public abstract Message receive(long paramLong)
    throws JMSException;

  public abstract Message receiveNoWait()
    throws JMSException;

  public abstract void close()
    throws JMSException;
}