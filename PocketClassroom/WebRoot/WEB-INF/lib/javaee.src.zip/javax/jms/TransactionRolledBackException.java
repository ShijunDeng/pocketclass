package javax.jms;

public class TransactionRolledBackException extends JMSException
{
  public TransactionRolledBackException(String reason, String errorCode)
  {
    super(reason, errorCode);
  }

  public TransactionRolledBackException(String reason)
  {
    super(reason);
  }
}