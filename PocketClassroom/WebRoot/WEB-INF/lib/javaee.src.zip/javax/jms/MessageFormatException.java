package javax.jms;

public class MessageFormatException extends JMSException
{
  public MessageFormatException(String reason, String errorCode)
  {
    super(reason, errorCode);
  }

  public MessageFormatException(String reason)
  {
    super(reason);
  }
}