package javax.jms;

public abstract interface XATopicSession extends XASession
{
  public abstract TopicSession getTopicSession()
    throws JMSException;
}