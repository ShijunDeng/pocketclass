package javax.jms;

import java.util.Enumeration;

public abstract interface QueueBrowser
{
  public abstract Queue getQueue()
    throws JMSException;

  public abstract String getMessageSelector()
    throws JMSException;

  public abstract Enumeration getEnumeration()
    throws JMSException;

  public abstract void close()
    throws JMSException;
}