package javax.jms;

public abstract interface XAQueueSession extends XASession
{
  public abstract QueueSession getQueueSession()
    throws JMSException;
}