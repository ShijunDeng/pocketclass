package javax.jms;

public abstract interface QueueConnectionFactory extends ConnectionFactory
{
  public abstract QueueConnection createQueueConnection()
    throws JMSException;

  public abstract QueueConnection createQueueConnection(String paramString1, String paramString2)
    throws JMSException;
}