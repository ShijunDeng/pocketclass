package javax.jms;

public abstract interface MessageProducer
{
  public abstract void setDisableMessageID(boolean paramBoolean)
    throws JMSException;

  public abstract boolean getDisableMessageID()
    throws JMSException;

  public abstract void setDisableMessageTimestamp(boolean paramBoolean)
    throws JMSException;

  public abstract boolean getDisableMessageTimestamp()
    throws JMSException;

  public abstract void setDeliveryMode(int paramInt)
    throws JMSException;

  public abstract int getDeliveryMode()
    throws JMSException;

  public abstract void setPriority(int paramInt)
    throws JMSException;

  public abstract int getPriority()
    throws JMSException;

  public abstract void setTimeToLive(long paramLong)
    throws JMSException;

  public abstract long getTimeToLive()
    throws JMSException;

  public abstract Destination getDestination()
    throws JMSException;

  public abstract void close()
    throws JMSException;

  public abstract void send(Message paramMessage)
    throws JMSException;

  public abstract void send(Message paramMessage, int paramInt1, int paramInt2, long paramLong)
    throws JMSException;

  public abstract void send(Destination paramDestination, Message paramMessage)
    throws JMSException;

  public abstract void send(Destination paramDestination, Message paramMessage, int paramInt1, int paramInt2, long paramLong)
    throws JMSException;
}