package javax.jms;

public abstract interface QueueSession extends Session
{
  public abstract Queue createQueue(String paramString)
    throws JMSException;

  public abstract QueueReceiver createReceiver(Queue paramQueue)
    throws JMSException;

  public abstract QueueReceiver createReceiver(Queue paramQueue, String paramString)
    throws JMSException;

  public abstract QueueSender createSender(Queue paramQueue)
    throws JMSException;

  public abstract QueueBrowser createBrowser(Queue paramQueue)
    throws JMSException;

  public abstract QueueBrowser createBrowser(Queue paramQueue, String paramString)
    throws JMSException;

  public abstract TemporaryQueue createTemporaryQueue()
    throws JMSException;
}