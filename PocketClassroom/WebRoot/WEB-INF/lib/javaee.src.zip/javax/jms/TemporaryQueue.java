package javax.jms;

public abstract interface TemporaryQueue extends Queue
{
  public abstract void delete()
    throws JMSException;
}