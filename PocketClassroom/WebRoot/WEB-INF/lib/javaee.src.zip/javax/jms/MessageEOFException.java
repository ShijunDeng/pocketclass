package javax.jms;

public class MessageEOFException extends JMSException
{
  public MessageEOFException(String reason, String errorCode)
  {
    super(reason, errorCode);
  }

  public MessageEOFException(String reason)
  {
    super(reason);
  }
}