package javax.jms;

public abstract interface ServerSession
{
  public abstract Session getSession()
    throws JMSException;

  public abstract void start()
    throws JMSException;
}