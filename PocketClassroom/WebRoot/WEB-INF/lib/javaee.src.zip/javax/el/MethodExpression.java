package javax.el;

public abstract class MethodExpression extends Expression
{
  public abstract MethodInfo getMethodInfo(ELContext paramELContext);

  public abstract Object invoke(ELContext paramELContext, Object[] paramArrayOfObject);
}