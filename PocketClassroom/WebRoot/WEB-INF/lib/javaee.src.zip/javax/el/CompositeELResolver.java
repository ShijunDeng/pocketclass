package javax.el;

import java.beans.FeatureDescriptor;
import java.util.ArrayList;
import java.util.Iterator;

public class CompositeELResolver extends ELResolver
{
  private final ArrayList<ELResolver> elResolvers;

  public CompositeELResolver()
  {
    this.elResolvers = new ArrayList();
  }

  public void add(ELResolver elResolver)
  {
    if (elResolver == null) {
      throw new NullPointerException();
    }

    this.elResolvers.add(elResolver);
  }

  public Object getValue(ELContext context, Object base, Object property)
  {
    context.setPropertyResolved(false);
    int i = 0; int len = this.elResolvers.size();

    while (i < len) {
      ELResolver elResolver = (ELResolver)this.elResolvers.get(i);
      Object value = elResolver.getValue(context, base, property);
      if (context.isPropertyResolved())
        return value;

      ++i;
    }
    return null;
  }

  public Class<?> getType(ELContext context, Object base, Object property)
  {
    context.setPropertyResolved(false);
    int i = 0; int len = this.elResolvers.size();

    while (i < len) {
      ELResolver elResolver = (ELResolver)this.elResolvers.get(i);
      Class type = elResolver.getType(context, base, property);
      if (context.isPropertyResolved())
        return type;

      ++i;
    }
    return null;
  }

  public void setValue(ELContext context, Object base, Object property, Object val)
  {
    context.setPropertyResolved(false);
    int i = 0; int len = this.elResolvers.size();

    while (i < len) {
      ELResolver elResolver = (ELResolver)this.elResolvers.get(i);
      elResolver.setValue(context, base, property, val);
      if (context.isPropertyResolved())
        return;

      ++i;
    }
  }

  public boolean isReadOnly(ELContext context, Object base, Object property)
  {
    context.setPropertyResolved(false);
    int i = 0; int len = this.elResolvers.size();

    while (i < len) {
      ELResolver elResolver = (ELResolver)this.elResolvers.get(i);
      boolean readOnly = elResolver.isReadOnly(context, base, property);
      if (context.isPropertyResolved())
        return readOnly;

      ++i;
    }
    return false;
  }

  public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base)
  {
    return new CompositeIterator(this.elResolvers.iterator(), context, base);
  }

  public Class<?> getCommonPropertyType(ELContext context, Object base)
  {
    Class commonPropertyType = null;
    Iterator iter = this.elResolvers.iterator();
    while (true) { Class type;
      while (true) { while (true) { if (!(iter.hasNext())) break label92;
          ELResolver elResolver = (ELResolver)iter.next();
          type = elResolver.getCommonPropertyType(context, base);
          if (type != null)
            break;
        }
        if (commonPropertyType == null) {
          commonPropertyType = type;
          break label89: } if (!(commonPropertyType.isAssignableFrom(type))) break;
      }
      label89: if (type.isAssignableFrom(commonPropertyType)) {
        commonPropertyType = type;
      }
      else
        return null;
    }

    label92: return commonPropertyType;
  }

  private static class CompositeIterator
    implements Iterator<FeatureDescriptor>
  {
    Iterator<ELResolver> compositeIter;
    Iterator<FeatureDescriptor> propertyIter;
    ELContext context;
    Object base;

    CompositeIterator(Iterator<ELResolver> iter, ELContext context, Object base)
    {
      this.compositeIter = iter;
      this.context = context;
      this.base = base;
    }

    public boolean hasNext() {
      if ((this.propertyIter == null) || (!(this.propertyIter.hasNext()))) {
        while (this.compositeIter.hasNext()) {
          ELResolver elResolver = (ELResolver)this.compositeIter.next();
          this.propertyIter = elResolver.getFeatureDescriptors(this.context, this.base);

          if (this.propertyIter != null)
            return this.propertyIter.hasNext();
        }

        return false;
      }
      return this.propertyIter.hasNext();
    }

    public FeatureDescriptor next() {
      if ((this.propertyIter == null) || (!(this.propertyIter.hasNext()))) {
        while (this.compositeIter.hasNext()) {
          ELResolver elResolver = (ELResolver)this.compositeIter.next();
          this.propertyIter = elResolver.getFeatureDescriptors(this.context, this.base);

          if (this.propertyIter != null)
            return ((FeatureDescriptor)this.propertyIter.next());
        }

        return null;
      }
      return ((FeatureDescriptor)this.propertyIter.next());
    }

    public void remove() {
      throw new UnsupportedOperationException();
    }
  }
}