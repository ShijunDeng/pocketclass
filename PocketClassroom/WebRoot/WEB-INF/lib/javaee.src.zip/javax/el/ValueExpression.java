package javax.el;

public abstract class ValueExpression extends Expression
{
  public abstract Object getValue(ELContext paramELContext);

  public abstract void setValue(ELContext paramELContext, Object paramObject);

  public abstract boolean isReadOnly(ELContext paramELContext);

  public abstract Class<?> getType(ELContext paramELContext);

  public abstract Class<?> getExpectedType();
}