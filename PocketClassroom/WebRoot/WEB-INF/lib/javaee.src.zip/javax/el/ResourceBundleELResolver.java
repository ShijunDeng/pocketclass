package javax.el;

import java.beans.FeatureDescriptor;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class ResourceBundleELResolver extends ELResolver
{
  public Object getValue(ELContext context, Object base, Object property)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if (base instanceof ResourceBundle) {
      context.setPropertyResolved(true);
      if (property != null)
        try {
          return ((ResourceBundle)base).getObject(property.toString());
        }
        catch (MissingResourceException e) {
          return "???" + property + "???";
        }
    }

    return null;
  }

  public Class<?> getType(ELContext context, Object base, Object property)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if (base instanceof ResourceBundle)
      context.setPropertyResolved(true);

    return null;
  }

  public void setValue(ELContext context, Object base, Object property, Object value)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if (base instanceof ResourceBundle) {
      context.setPropertyResolved(true);
      throw new PropertyNotWritableException("ResourceBundles are immutable");
    }
  }

  public boolean isReadOnly(ELContext context, Object base, Object property)
  {
    if (context == null)
      throw new NullPointerException();

    if (base instanceof ResourceBundle) {
      context.setPropertyResolved(true);
      return true;
    }
    return false;
  }

  public Iterator getFeatureDescriptors(ELContext context, Object base)
  {
    if (base instanceof ResourceBundle) {
      ResourceBundle bundle = (ResourceBundle)base;
      List features = new ArrayList();
      String key = null;
      FeatureDescriptor desc = null;
      for (Enumeration e = bundle.getKeys(); e.hasMoreElements(); ) {
        key = (String)e.nextElement();
        desc = new FeatureDescriptor();
        desc.setDisplayName(key);
        desc.setExpert(false);
        desc.setHidden(false);
        desc.setName(key);
        desc.setPreferred(true);
        desc.setValue("type", String.class);
        desc.setValue("resolvableAtDesignTime", Boolean.TRUE);
        features.add(desc);
      }
      return features.iterator();
    }
    return null;
  }

  public Class<?> getCommonPropertyType(ELContext context, Object base)
  {
    if (base instanceof ResourceBundle)
      return String.class;

    return null;
  }
}