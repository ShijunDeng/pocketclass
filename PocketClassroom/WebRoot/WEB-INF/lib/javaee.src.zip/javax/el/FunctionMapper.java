package javax.el;

import java.lang.reflect.Method;

public abstract class FunctionMapper
{
  public abstract Method resolveFunction(String paramString1, String paramString2);
}