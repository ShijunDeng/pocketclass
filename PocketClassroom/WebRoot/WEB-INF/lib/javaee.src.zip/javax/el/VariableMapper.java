package javax.el;

public abstract class VariableMapper
{
  public abstract ValueExpression resolveVariable(String paramString);

  public abstract ValueExpression setVariable(String paramString, ValueExpression paramValueExpression);
}