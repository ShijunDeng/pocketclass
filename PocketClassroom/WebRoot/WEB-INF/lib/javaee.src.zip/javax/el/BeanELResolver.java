package javax.el;

import java.beans.BeanInfo;
import java.beans.FeatureDescriptor;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BeanELResolver extends ELResolver
{
  private boolean isReadOnly;
  private static final int SIZE = 2000;
  private static final Map<Class, BeanProperties> properties = new ConcurrentHashMap(2000);
  private static final Map<Class, BeanProperties> properties2 = new ConcurrentHashMap(2000);

  public BeanELResolver()
  {
    this.isReadOnly = false;
  }

  public BeanELResolver(boolean isReadOnly)
  {
    this.isReadOnly = isReadOnly;
  }

  public Class<?> getType(ELContext context, Object base, Object property)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if ((base == null) || (property == null)) {
      return null;
    }

    BeanProperty bp = getBeanProperty(context, base, property);
    context.setPropertyResolved(true);
    return bp.getPropertyType();
  }

  public Object getValue(ELContext context, Object base, Object property)
  {
    Object value;
    if (context == null) {
      throw new NullPointerException();
    }

    if ((base == null) || (property == null)) {
      return null;
    }

    BeanProperty bp = getBeanProperty(context, base, property);
    Method method = bp.getReadMethod();
    if (method == null) {
      throw new PropertyNotFoundException(ELUtil.getExceptionMessageString(context, "propertyNotReadable", new Object[] { base.getClass().getName(), property.toString() }));
    }

    try
    {
      value = method.invoke(base, new Object[0]);
      context.setPropertyResolved(true);
    } catch (ELException ex) {
      throw ex;
    } catch (InvocationTargetException ite) {
      throw new ELException(ite.getCause());
    } catch (Exception ex) {
      throw new ELException(ex);
    }
    return value;
  }

  public void setValue(ELContext context, Object base, Object property, Object val)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if ((base == null) || (property == null)) {
      return;
    }

    if (this.isReadOnly) {
      throw new PropertyNotWritableException(ELUtil.getExceptionMessageString(context, "resolverNotwritable", new Object[] { base.getClass().getName() }));
    }

    BeanProperty bp = getBeanProperty(context, base, property);
    Method method = bp.getWriteMethod();
    if (method == null) {
      throw new PropertyNotWritableException(ELUtil.getExceptionMessageString(context, "propertyNotWritable", new Object[] { base.getClass().getName(), property.toString() }));
    }

    try
    {
      method.invoke(base, new Object[] { val });
      context.setPropertyResolved(true);
    } catch (ELException ex) {
      throw ex;
    } catch (InvocationTargetException ite) {
      throw new ELException(ite.getCause());
    } catch (Exception ex) {
      if (null == val)
        val = "null";

      String message = ELUtil.getExceptionMessageString(context, "setPropertyFailed", new Object[] { property.toString(), base.getClass().getName(), val });

      throw new ELException(message, ex);
    }
  }

  public boolean isReadOnly(ELContext context, Object base, Object property)
  {
    if (context == null) {
      throw new NullPointerException();
    }

    if ((base == null) || (property == null)) {
      return false;
    }

    context.setPropertyResolved(true);
    if (this.isReadOnly) {
      return true;
    }

    BeanProperty bp = getBeanProperty(context, base, property);
    return bp.isReadOnly();
  }

  public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base)
  {
    if (base == null) {
      return null;
    }

    BeanInfo info = null;
    try {
      info = Introspector.getBeanInfo(base.getClass());
    } catch (Exception ex) {
    }
    if (info == null)
      return null;

    ArrayList list = new ArrayList(info.getPropertyDescriptors().length);

    for (PropertyDescriptor pd : info.getPropertyDescriptors()) {
      pd.setValue("type", pd.getPropertyType());
      pd.setValue("resolvableAtDesignTime", Boolean.TRUE);
      list.add(pd);
    }
    return list.iterator();
  }

  public Class<?> getCommonPropertyType(ELContext context, Object base)
  {
    if (base == null) {
      return null;
    }

    return Object.class;
  }

  private static Method getMethod(Class cl, Method method)
  {
    if (Modifier.isPublic(cl.getModifiers()))
      return method;

    Class[] interfaces = cl.getInterfaces();
    for (int i = 0; i < interfaces.length; ++i) {
      Class c = interfaces[i];
      Method m = null;
      try {
        m = c.getMethod(method.getName(), method.getParameterTypes());
        c = m.getDeclaringClass();
        if ((m = getMethod(c, m)) != null)
          return m;
      } catch (NoSuchMethodException ex) {
      }
    }
    Class c = cl.getSuperclass();
    if (c != null) {
      Method m = null;
      try {
        m = c.getMethod(method.getName(), method.getParameterTypes());
        c = m.getDeclaringClass();
        if ((m = getMethod(c, m)) != null)
          return m;
      } catch (NoSuchMethodException ex) {
      }
    }
    return null;
  }

  private BeanProperty getBeanProperty(ELContext context, Object base, Object prop)
  {
    String property = prop.toString();
    Class baseClass = base.getClass();
    BeanProperties bps = (BeanProperties)properties.get(baseClass);
    if (bps == null) if ((bps = (BeanProperties)properties2.get(baseClass)) == null) {
        if (properties.size() > 2000)
        {
          properties2.clear();
          properties2.putAll(properties);
          properties.clear();
        }
        bps = new BeanProperties(baseClass);
        properties.put(baseClass, bps);
      }
    BeanProperty bp = bps.getBeanProperty(property);
    if (bp == null) {
      throw new PropertyNotFoundException(ELUtil.getExceptionMessageString(context, "propertyNotFound", new Object[] { baseClass.getName(), property }));
    }

    return bp;
  }

  protected static final class BeanProperties
  {
    private final Class baseClass;
    private final Map<String, BeanELResolver.BeanProperty> propertyMap = new HashMap();

    public BeanProperties(Class<?> baseClass)
    {
      this.baseClass = baseClass;
      try
      {
        BeanInfo info = Introspector.getBeanInfo(baseClass);
        descriptors = info.getPropertyDescriptors();
      } catch (IntrospectionException ie) {
        throw new ELException(ie);
      }
      for (PropertyDescriptor pd : descriptors)
        this.propertyMap.put(pd.getName(), new BeanELResolver.BeanProperty(baseClass, pd));
    }

    public BeanELResolver.BeanProperty getBeanProperty(String property)
    {
      return ((BeanELResolver.BeanProperty)this.propertyMap.get(property));
    }
  }

  protected static final class BeanProperty
  {
    private Method readMethod;
    private Method writeMethod;
    private Class baseClass;
    private PropertyDescriptor descriptor;

    public BeanProperty(Class<?> baseClass, PropertyDescriptor descriptor)
    {
      this.baseClass = baseClass;
      this.descriptor = descriptor;
    }

    public Class getPropertyType() {
      return this.descriptor.getPropertyType();
    }

    public boolean isReadOnly() {
      return (getWriteMethod() == null);
    }

    public Method getReadMethod() {
      if (this.readMethod == null)
        this.readMethod = BeanELResolver.access$000(this.baseClass, this.descriptor.getReadMethod());

      return this.readMethod;
    }

    public Method getWriteMethod() {
      if (this.writeMethod == null)
        this.writeMethod = BeanELResolver.access$000(this.baseClass, this.descriptor.getWriteMethod());

      return this.writeMethod;
    }
  }
}