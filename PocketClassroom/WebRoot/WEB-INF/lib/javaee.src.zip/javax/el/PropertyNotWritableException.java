package javax.el;

public class PropertyNotWritableException extends ELException
{
  public PropertyNotWritableException()
  {
  }

  public PropertyNotWritableException(String pMessage)
  {
    super(pMessage);
  }

  public PropertyNotWritableException(Throwable exception)
  {
    super(exception);
  }

  public PropertyNotWritableException(String pMessage, Throwable pRootCause)
  {
    super(pMessage, pRootCause);
  }
}