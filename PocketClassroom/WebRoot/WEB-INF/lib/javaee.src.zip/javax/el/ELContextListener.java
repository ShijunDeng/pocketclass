package javax.el;

import java.util.EventListener;

public abstract interface ELContextListener extends EventListener
{
  public abstract void contextCreated(ELContextEvent paramELContextEvent);
}