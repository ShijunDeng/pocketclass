package javax.el;

public class PropertyNotFoundException extends ELException
{
  public PropertyNotFoundException()
  {
  }

  public PropertyNotFoundException(String message)
  {
    super(message);
  }

  public PropertyNotFoundException(Throwable exception)
  {
    super(exception);
  }

  public PropertyNotFoundException(String pMessage, Throwable pRootCause)
  {
    super(pMessage, pRootCause);
  }
}