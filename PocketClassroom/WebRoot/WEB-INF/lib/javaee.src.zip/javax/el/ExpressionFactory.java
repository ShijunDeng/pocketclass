package javax.el;

public abstract class ExpressionFactory
{
  public abstract ValueExpression createValueExpression(ELContext paramELContext, String paramString, Class<?> paramClass);

  public abstract ValueExpression createValueExpression(Object paramObject, Class<?> paramClass);

  public abstract MethodExpression createMethodExpression(ELContext paramELContext, String paramString, Class<?> paramClass, Class<?>[] paramArrayOfClass);

  public abstract Object coerceToType(Object paramObject, Class<?> paramClass);
}