package javax.activation;

import com.sun.activation.registries.LogSupport;
import com.sun.activation.registries.MailcapFile;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MailcapCommandMap extends CommandMap
{
  private static MailcapFile defDB = null;
  private MailcapFile[] DB;
  private static final int PROG = 0;

  public MailcapCommandMap()
  {
    List dbv = new ArrayList(5);
    MailcapFile mf = null;
    dbv.add(null);

    LogSupport.log("MailcapCommandMap: load HOME");
    try {
      String user_home = System.getProperty("user.home");

      if (user_home != null) {
        String path = user_home + File.separator + ".mailcap";
        mf = loadFile(path);
        if (mf != null)
          dbv.add(mf);
      }
    } catch (SecurityException user_home) {
    }
    LogSupport.log("MailcapCommandMap: load SYS");
    try
    {
      String system_mailcap = System.getProperty("java.home") + File.separator + "lib" + File.separator + "mailcap";

      mf = loadFile(system_mailcap);
      if (mf != null)
        dbv.add(mf);
    } catch (SecurityException system_mailcap) {
    }
    LogSupport.log("MailcapCommandMap: load JAR");

    loadAllResources(dbv, "META-INF/mailcap");

    LogSupport.log("MailcapCommandMap: load DEF");
    synchronized (MailcapCommandMap.class)
    {
      if (defDB == null)
        defDB = loadResource("/META-INF/mailcap.default");
    }

    if (defDB != null)
      dbv.add(defDB);

    this.DB = new MailcapFile[dbv.size()];
    this.DB = ((MailcapFile[])(MailcapFile[])dbv.toArray(this.DB));
  }

  private MailcapFile loadResource(String name)
  {
    InputStream clis = null;
    try {
      clis = SecuritySupport.getResourceAsStream(getClass(), name);
      if (clis != null) {
        MailcapFile mf = new MailcapFile(clis);
        if (LogSupport.isLoggable())
          LogSupport.log("MailcapCommandMap: successfully loaded mailcap file: " + name);

        MailcapFile localMailcapFile1 = mf;

        return localMailcapFile1;
      }
      if (LogSupport.isLoggable())
        LogSupport.log("MailcapCommandMap: not loading mailcap file: " + name);
    }
    catch (IOException e)
    {
      if (LogSupport.isLoggable())
        LogSupport.log("MailcapCommandMap: can't load " + name, e);
    } catch (SecurityException sex) {
      if (LogSupport.isLoggable())
        LogSupport.log("MailcapCommandMap: can't load " + name, sex);
    } finally {
      try {
        if (clis != null)
          clis.close(); 
      } catch (IOException ex) {
      }
    }
    return null;
  }

  private void loadAllResources(List v, String name)
  {
    URL[] urls;
    int i;
    boolean anyLoaded = false;
    try
    {
      ClassLoader cld = null;

      cld = SecuritySupport.getContextClassLoader();
      if (cld == null)
        cld = getClass().getClassLoader();
      if (cld != null)
        urls = SecuritySupport.getResources(cld, name);
      else
        urls = SecuritySupport.getSystemResources(name);
      if (urls != null) {
        if (LogSupport.isLoggable())
          LogSupport.log("MailcapCommandMap: getResources");
        for (i = 0; i < urls.length; ++i) {
          URL url = urls[i];
          InputStream clis = null;
          if (LogSupport.isLoggable())
            LogSupport.log("MailcapCommandMap: URL " + url);
          try {
            clis = SecuritySupport.openStream(url);
            if (clis != null) {
              v.add(new MailcapFile(clis));
              anyLoaded = true;
              if (LogSupport.isLoggable()) {
                LogSupport.log("MailcapCommandMap: successfully loaded mailcap file from URL: " + url);
              }

            }
            else if (LogSupport.isLoggable()) {
              LogSupport.log("MailcapCommandMap: not loading mailcap file from URL: " + url);
            }
          }
          catch (IOException ioex)
          {
            if (LogSupport.isLoggable())
              LogSupport.log("MailcapCommandMap: can't load " + url, ioex);
          }
          catch (SecurityException sex) {
            if (LogSupport.isLoggable())
              LogSupport.log("MailcapCommandMap: can't load " + url, sex);
          }
          finally {
            try {
              if (clis != null)
                clis.close(); 
            } catch (IOException cex) {
            }
          }
        }
      }
    } catch (Exception ex) {
      if (LogSupport.isLoggable())
        LogSupport.log("MailcapCommandMap: can't load " + name, ex);

    }

    if (!(anyLoaded)) {
      if (LogSupport.isLoggable())
        LogSupport.log("MailcapCommandMap: !anyLoaded");
      MailcapFile mf = loadResource("/" + name);
      if (mf != null)
        v.add(mf);
    }
  }

  private MailcapFile loadFile(String name)
  {
    MailcapFile mtf = null;
    try
    {
      mtf = new MailcapFile(name);
    }
    catch (IOException e) {
    }
    return mtf;
  }

  public MailcapCommandMap(String fileName)
    throws IOException
  {
    if (LogSupport.isLoggable())
      LogSupport.log("MailcapCommandMap: load PROG from " + fileName);
    if (this.DB[0] == null)
      this.DB[0] = new MailcapFile(fileName);
  }

  public MailcapCommandMap(InputStream is)
  {
    LogSupport.log("MailcapCommandMap: load PROG");
    if (this.DB[0] == null)
      try {
        this.DB[0] = new MailcapFile(is);
      }
      catch (IOException ex)
      {
      }
  }

  public synchronized CommandInfo[] getPreferredCommands(String mimeType)
  {
    Map cmdMap;
    List cmdList = new ArrayList();
    if (mimeType != null)
      mimeType = mimeType.toLowerCase();

    for (int i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label64:
      cmdMap = this.DB[i].getMailcapList(mimeType);
      if (cmdMap != null)
        appendPrefCmdsToList(cmdMap, cmdList);

    }

    for (i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        label64: break label117:
      cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
      if (cmdMap != null)
        appendPrefCmdsToList(cmdMap, cmdList);
    }

    label117: CommandInfo[] cmdInfos = new CommandInfo[cmdList.size()];
    cmdInfos = (CommandInfo[])(CommandInfo[])cmdList.toArray(cmdInfos);

    return cmdInfos;
  }

  private void appendPrefCmdsToList(Map cmdHash, List cmdList)
  {
    Iterator verb_enum = cmdHash.keySet().iterator();

    while (verb_enum.hasNext()) {
      String verb = (String)verb_enum.next();
      if (!(checkForVerb(cmdList, verb))) {
        List cmdList2 = (List)cmdHash.get(verb);
        String className = (String)cmdList2.get(0);
        cmdList.add(new CommandInfo(verb, className));
      }
    }
  }

  private boolean checkForVerb(List cmdList, String verb)
  {
    Iterator ee = cmdList.iterator();
    while (ee.hasNext()) {
      String enum_verb = ((CommandInfo)ee.next()).getCommandName();

      if (enum_verb.equals(verb))
        return true;
    }
    return false;
  }

  public synchronized CommandInfo[] getAllCommands(String mimeType)
  {
    Map cmdMap;
    List cmdList = new ArrayList();
    if (mimeType != null)
      mimeType = mimeType.toLowerCase();

    for (int i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label64:
      cmdMap = this.DB[i].getMailcapList(mimeType);
      if (cmdMap != null)
        appendCmdsToList(cmdMap, cmdList);

    }

    for (i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        label64: break label117:
      cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
      if (cmdMap != null)
        appendCmdsToList(cmdMap, cmdList);
    }

    label117: CommandInfo[] cmdInfos = new CommandInfo[cmdList.size()];
    cmdInfos = (CommandInfo[])(CommandInfo[])cmdList.toArray(cmdInfos);

    return cmdInfos;
  }

  private void appendCmdsToList(Map typeHash, List cmdList)
  {
    Iterator verb_enum = typeHash.keySet().iterator();

    while (verb_enum.hasNext()) {
      String verb = (String)verb_enum.next();
      List cmdList2 = (List)typeHash.get(verb);
      Iterator cmd_enum = cmdList2.iterator();

      while (cmd_enum.hasNext()) {
        String cmd = (String)cmd_enum.next();
        cmdList.add(new CommandInfo(verb, cmd));
      }
    }
  }

  public synchronized CommandInfo getCommand(String mimeType, String cmdName)
  {
    Map cmdMap;
    List v;
    String cmdClassName;
    if (mimeType != null)
      mimeType = mimeType.toLowerCase();

    for (int i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label96:
      cmdMap = this.DB[i].getMailcapList(mimeType);
      if (cmdMap != null)
      {
        v = (List)cmdMap.get(cmdName);
        if (v != null) {
          cmdClassName = (String)v.get(0);

          if (cmdClassName != null)
            return new CommandInfo(cmdName, cmdClassName);
        }
      }

    }

    for (i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        label96: break label189:
      cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
      if (cmdMap != null)
      {
        v = (List)cmdMap.get(cmdName);
        if (v != null) {
          cmdClassName = (String)v.get(0);

          if (cmdClassName != null)
            return new CommandInfo(cmdName, cmdClassName);
        }
      }
    }
    label189: return null;
  }

  public synchronized void addMailcap(String mail_cap)
  {
    LogSupport.log("MailcapCommandMap: add to PROG");
    if (this.DB[0] == null)
      this.DB[0] = new MailcapFile();

    this.DB[0].appendToMailcap(mail_cap);
  }

  public synchronized DataContentHandler createDataContentHandler(String mimeType)
  {
    Map cmdMap;
    List v;
    String name;
    DataContentHandler dch;
    if (LogSupport.isLoggable())
      LogSupport.log("MailcapCommandMap: createDataContentHandler for " + mimeType);

    if (mimeType != null)
      mimeType = mimeType.toLowerCase();

    for (int i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        break label150:
      if (LogSupport.isLoggable())
        LogSupport.log("  search DB #" + i);
      cmdMap = this.DB[i].getMailcapList(mimeType);
      if (cmdMap != null) {
        v = (List)cmdMap.get("content-handler");
        if (v != null) {
          name = (String)v.get(0);
          dch = getDataContentHandler(name);
          if (dch != null)
            return dch;
        }
      }

    }

    for (i = 0; i < this.DB.length; ++i) {
      if (this.DB[i] == null)
        label150: break label269:
      if (LogSupport.isLoggable())
        LogSupport.log("  search fallback DB #" + i);
      cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
      if (cmdMap != null) {
        v = (List)cmdMap.get("content-handler");
        if (v != null) {
          name = (String)v.get(0);
          dch = getDataContentHandler(name);
          if (dch != null)
            return dch;
        }
      }
    }
    label269: return null;
  }

  private DataContentHandler getDataContentHandler(String name) {
    if (LogSupport.isLoggable())
      LogSupport.log("    got content-handler");
    if (LogSupport.isLoggable())
      LogSupport.log("      class " + name);
    try {
      ClassLoader cld = null;

      cld = SecuritySupport.getContextClassLoader();
      if (cld == null)
        cld = getClass().getClassLoader();
      Class cl = null;
      try {
        cl = cld.loadClass(name);
      }
      catch (Exception ex) {
        cl = Class.forName(name);
      }
      if (cl != null)
        return ((DataContentHandler)cl.newInstance());
    } catch (IllegalAccessException e) {
      if (LogSupport.isLoggable())
        LogSupport.log("Can't load DCH " + name, e);
    } catch (ClassNotFoundException e) {
      if (LogSupport.isLoggable())
        LogSupport.log("Can't load DCH " + name, e);
    } catch (InstantiationException e) {
      if (LogSupport.isLoggable())
        LogSupport.log("Can't load DCH " + name, e);
    }
    return null;
  }

  public synchronized String[] getMimeTypes()
  {
    List mtList = new ArrayList();

    for (int i = 0; i < this.DB.length; ++i) {
      int j;
      if (this.DB[i] == null)
        break label85:
      String[] ts = this.DB[i].getMimeTypes();
      if (ts != null)
        for (j = 0; j < ts.length; ++j)
        {
          if (!(mtList.contains(ts[j])))
            mtList.add(ts[j]);
        }

    }

    label85: String[] mts = new String[mtList.size()];
    mts = (String[])(String[])mtList.toArray(mts);

    return mts;
  }

  public synchronized String[] getNativeCommands(String mimeType)
  {
    List cmdList = new ArrayList();
    if (mimeType != null)
      mimeType = mimeType.toLowerCase();

    for (int i = 0; i < this.DB.length; ++i) {
      int j;
      if (this.DB[i] == null)
        break label100:
      String[] cmds = this.DB[i].getNativeCommands(mimeType);
      if (cmds != null)
        for (j = 0; j < cmds.length; ++j)
        {
          if (!(cmdList.contains(cmds[j])))
            cmdList.add(cmds[j]);
        }

    }

    label100: String[] cmds = new String[cmdList.size()];
    cmds = (String[])(String[])cmdList.toArray(cmds);

    return cmds;
  }
}