package javax.jws.soap;

import java.lang.annotation.Annotation;

@Deprecated
public @interface InitParam
{
  public abstract String name();

  public abstract String value();
}