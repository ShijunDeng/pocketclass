package javax.jws;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.PARAMETER})
public @interface WebParam
{
  public abstract String name();

  public abstract String partName();

  public abstract String targetNamespace();

  public abstract Mode mode();

  public abstract boolean header();

  public static enum Mode
  {
    IN, OUT, INOUT;

    public static final Mode[] values()
    {
      return ((Mode[])$VALUES.clone());
    }
  }
}