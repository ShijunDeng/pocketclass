package javax.ejb;

public class DuplicateKeyException extends CreateException
{
  public DuplicateKeyException()
  {
  }

  public DuplicateKeyException(String message)
  {
    super(message);
  }
}