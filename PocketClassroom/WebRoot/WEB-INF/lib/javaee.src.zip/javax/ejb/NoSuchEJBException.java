package javax.ejb;

public class NoSuchEJBException extends EJBException
{
  public NoSuchEJBException()
  {
  }

  public NoSuchEJBException(String message)
  {
    super(message);
  }

  public NoSuchEJBException(String message, Exception ex)
  {
    super(message, ex);
  }
}