package javax.ejb;

public class EJBTransactionRequiredException extends EJBException
{
  public EJBTransactionRequiredException()
  {
  }

  public EJBTransactionRequiredException(String message)
  {
    super(message);
  }
}