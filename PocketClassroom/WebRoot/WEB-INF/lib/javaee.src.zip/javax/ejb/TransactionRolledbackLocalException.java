package javax.ejb;

public class TransactionRolledbackLocalException extends EJBException
{
  public TransactionRolledbackLocalException()
  {
  }

  public TransactionRolledbackLocalException(String message)
  {
    super(message);
  }

  public TransactionRolledbackLocalException(String message, Exception ex)
  {
    super(message, ex);
  }
}