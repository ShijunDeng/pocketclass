package javax.ejb;

public class CreateException extends Exception
{
  public CreateException()
  {
  }

  public CreateException(String message)
  {
    super(message);
  }
}