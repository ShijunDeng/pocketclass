package javax.ejb;

import java.io.Serializable;
import java.rmi.RemoteException;

public abstract interface Handle extends Serializable
{
  public abstract EJBObject getEJBObject()
    throws RemoteException;
}