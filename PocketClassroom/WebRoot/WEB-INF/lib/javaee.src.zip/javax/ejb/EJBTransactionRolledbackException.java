package javax.ejb;

public class EJBTransactionRolledbackException extends EJBException
{
  public EJBTransactionRolledbackException()
  {
  }

  public EJBTransactionRolledbackException(String message)
  {
    super(message);
  }

  public EJBTransactionRolledbackException(String message, Exception ex)
  {
    super(message, ex);
  }
}