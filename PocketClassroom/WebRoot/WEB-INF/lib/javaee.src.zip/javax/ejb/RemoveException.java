package javax.ejb;

public class RemoveException extends Exception
{
  public RemoveException()
  {
  }

  public RemoveException(String message)
  {
    super(message);
  }
}