package javax.ejb;

public abstract interface MessageDrivenBean extends EnterpriseBean
{
  public abstract void setMessageDrivenContext(MessageDrivenContext paramMessageDrivenContext)
    throws EJBException;

  public abstract void ejbRemove()
    throws EJBException;
}