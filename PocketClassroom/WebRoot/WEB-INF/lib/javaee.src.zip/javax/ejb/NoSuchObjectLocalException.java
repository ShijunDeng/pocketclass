package javax.ejb;

public class NoSuchObjectLocalException extends EJBException
{
  public NoSuchObjectLocalException()
  {
  }

  public NoSuchObjectLocalException(String message)
  {
    super(message);
  }

  public NoSuchObjectLocalException(String message, Exception ex)
  {
    super(message, ex);
  }
}