package javax.ejb;

import java.rmi.Remote;
import java.rmi.RemoteException;

public abstract interface EJBHome extends Remote
{
  public abstract void remove(Handle paramHandle)
    throws RemoteException, RemoveException;

  public abstract void remove(Object paramObject)
    throws RemoteException, RemoveException;

  public abstract EJBMetaData getEJBMetaData()
    throws RemoteException;

  public abstract HomeHandle getHomeHandle()
    throws RemoteException;
}