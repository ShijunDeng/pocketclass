package javax.ejb;

public abstract interface EntityContext extends EJBContext
{
  public abstract EJBLocalObject getEJBLocalObject()
    throws IllegalStateException;

  public abstract EJBObject getEJBObject()
    throws IllegalStateException;

  public abstract Object getPrimaryKey()
    throws IllegalStateException;
}