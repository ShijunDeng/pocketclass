package javax.ejb;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

public abstract interface TimerService
{
  public abstract Timer createTimer(long paramLong, Serializable paramSerializable)
    throws IllegalArgumentException, IllegalStateException, EJBException;

  public abstract Timer createTimer(long paramLong1, long paramLong2, Serializable paramSerializable)
    throws IllegalArgumentException, IllegalStateException, EJBException;

  public abstract Timer createTimer(Date paramDate, Serializable paramSerializable)
    throws IllegalArgumentException, IllegalStateException, EJBException;

  public abstract Timer createTimer(Date paramDate, long paramLong, Serializable paramSerializable)
    throws IllegalArgumentException, IllegalStateException, EJBException;

  public abstract Collection getTimers()
    throws IllegalStateException, EJBException;
}