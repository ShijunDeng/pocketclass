package javax.ejb;

public class AccessLocalException extends EJBException
{
  public AccessLocalException()
  {
  }

  public AccessLocalException(String message)
  {
    super(message);
  }

  public AccessLocalException(String message, Exception ex)
  {
    super(message, ex);
  }
}