package javax.ejb;

public abstract interface TimedObject
{
  public abstract void ejbTimeout(Timer paramTimer);
}