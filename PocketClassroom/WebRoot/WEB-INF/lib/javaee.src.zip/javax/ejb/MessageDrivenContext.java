package javax.ejb;

public abstract interface MessageDrivenContext extends EJBContext
{
}