package javax.ejb;

import java.rmi.RemoteException;

public abstract interface SessionSynchronization
{
  public abstract void afterBegin()
    throws EJBException, RemoteException;

  public abstract void beforeCompletion()
    throws EJBException, RemoteException;

  public abstract void afterCompletion(boolean paramBoolean)
    throws EJBException, RemoteException;
}