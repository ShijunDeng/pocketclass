package javax.ejb;

public class TransactionRequiredLocalException extends EJBException
{
  public TransactionRequiredLocalException()
  {
  }

  public TransactionRequiredLocalException(String message)
  {
    super(message);
  }
}