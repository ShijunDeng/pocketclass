package javax.ejb;

import java.security.Identity;
import java.security.Principal;
import java.util.Properties;
import javax.transaction.UserTransaction;

public abstract interface EJBContext
{
  public abstract EJBHome getEJBHome();

  public abstract EJBLocalHome getEJBLocalHome();

  /**
   * @deprecated
   */
  public abstract Properties getEnvironment();

  /**
   * @deprecated
   */
  public abstract Identity getCallerIdentity();

  public abstract Principal getCallerPrincipal();

  /**
   * @deprecated
   */
  public abstract boolean isCallerInRole(Identity paramIdentity);

  public abstract boolean isCallerInRole(String paramString);

  public abstract UserTransaction getUserTransaction()
    throws IllegalStateException;

  public abstract void setRollbackOnly()
    throws IllegalStateException;

  public abstract boolean getRollbackOnly()
    throws IllegalStateException;

  public abstract TimerService getTimerService()
    throws IllegalStateException;

  public abstract Object lookup(String paramString);
}