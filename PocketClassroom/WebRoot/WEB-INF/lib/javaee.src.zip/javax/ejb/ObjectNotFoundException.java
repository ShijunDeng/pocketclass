package javax.ejb;

public class ObjectNotFoundException extends FinderException
{
  public ObjectNotFoundException()
  {
  }

  public ObjectNotFoundException(String message)
  {
    super(message);
  }
}