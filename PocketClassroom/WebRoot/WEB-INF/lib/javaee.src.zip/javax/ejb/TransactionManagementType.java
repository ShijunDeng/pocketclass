package javax.ejb;

public enum TransactionManagementType
{
  CONTAINER, BEAN;

  public static final TransactionManagementType[] values()
  {
    return ((TransactionManagementType[])$VALUES.clone());
  }
}