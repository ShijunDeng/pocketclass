package javax.ejb;

import java.io.Serializable;

public abstract interface TimerHandle extends Serializable
{
  public abstract Timer getTimer()
    throws IllegalStateException, NoSuchObjectLocalException, EJBException;
}