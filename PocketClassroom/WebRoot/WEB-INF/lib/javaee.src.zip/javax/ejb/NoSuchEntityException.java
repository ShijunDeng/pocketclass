package javax.ejb;

public class NoSuchEntityException extends EJBException
{
  public NoSuchEntityException()
  {
  }

  public NoSuchEntityException(String message)
  {
    super(message);
  }

  public NoSuchEntityException(Exception ex)
  {
    super(ex);
  }
}