package javax.mail;

import com.sun.mail.util.LineInputStream;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.net.InetAddress;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public final class Session
{
  private final Properties props;
  private final Authenticator authenticator;
  private final Hashtable authTable = new Hashtable();
  private boolean debug = false;
  private PrintStream out;
  private final Vector providers = new Vector();
  private final Hashtable providersByProtocol = new Hashtable();
  private final Hashtable providersByClassName = new Hashtable();
  private final Properties addressMap = new Properties();
  private static Session defaultSession = null;
  private static final String version = "1.4ea";

  private Session(Properties props, Authenticator authenticator)
  {
    this.props = props;
    this.authenticator = authenticator;

    if (Boolean.valueOf(props.getProperty("mail.debug")).booleanValue())
      this.debug = true;

    if (this.debug) {
      pr("DEBUG: JavaMail version 1.4ea");
    }

    if (authenticator != null)
      cl = authenticator.getClass();
    else
      cl = super.getClass();

    loadProviders(cl);
    loadAddressMap(cl);
  }

  public static Session getInstance(Properties props, Authenticator authenticator)
  {
    return new Session(props, authenticator);
  }

  public static Session getInstance(Properties props)
  {
    return new Session(props, null);
  }

  public static synchronized Session getDefaultInstance(Properties props, Authenticator authenticator)
  {
    if (defaultSession == null) {
      defaultSession = new Session(props, authenticator);
    }
    else {
      if (defaultSession.authenticator == authenticator)
        break label82:
      if ((defaultSession.authenticator != null) && (authenticator != null) && (defaultSession.authenticator.getClass().getClassLoader() == authenticator.getClass().getClassLoader()))
      {
        break label82:
      }

      throw new SecurityException("Access to default session denied");
    }

    label82: return defaultSession;
  }

  public static Session getDefaultInstance(Properties props)
  {
    return getDefaultInstance(props, null);
  }

  public synchronized void setDebug(boolean debug)
  {
    this.debug = debug;
    if (debug)
      pr("DEBUG: setDebug: JavaMail version 1.4ea");
  }

  public synchronized boolean getDebug()
  {
    return this.debug;
  }

  public synchronized void setDebugOut(PrintStream out)
  {
    this.out = out;
  }

  public synchronized PrintStream getDebugOut()
  {
    if (this.out == null)
      return System.out;

    return this.out;
  }

  public synchronized Provider[] getProviders()
  {
    Provider[] _providers = new Provider[this.providers.size()];
    this.providers.copyInto(_providers);
    return _providers;
  }

  public synchronized Provider getProvider(String protocol)
    throws NoSuchProviderException
  {
    if ((protocol == null) || (protocol.length() <= 0)) {
      throw new NoSuchProviderException("Invalid protocol: null");
    }

    Provider _provider = null;

    String _className = this.props.getProperty("mail." + protocol + ".class");
    if (_className != null) {
      if (this.debug) {
        pr("DEBUG: mail." + protocol + ".class property exists and points to " + _className);
      }

      _provider = (Provider)this.providersByClassName.get(_className);
    }

    if (_provider != null) {
      return _provider;
    }

    _provider = (Provider)this.providersByProtocol.get(protocol);

    if (_provider == null)
      throw new NoSuchProviderException("No provider for " + protocol);

    if (this.debug) {
      pr("DEBUG: getProvider() returning " + _provider.toString());
    }

    return _provider;
  }

  public synchronized void setProvider(Provider provider)
    throws NoSuchProviderException
  {
    if (provider == null)
      throw new NoSuchProviderException("Can't set null provider");

    this.providersByProtocol.put(provider.getProtocol(), provider);
    this.props.put("mail." + provider.getProtocol() + ".class", provider.getClassName());
  }

  public Store getStore()
    throws NoSuchProviderException
  {
    return getStore(getProperty("mail.store.protocol"));
  }

  public Store getStore(String protocol)
    throws NoSuchProviderException
  {
    return getStore(new URLName(protocol, null, -1, null, null, null));
  }

  public Store getStore(URLName url)
    throws NoSuchProviderException
  {
    String protocol = url.getProtocol();
    Provider p = getProvider(protocol);
    return getStore(p, url);
  }

  public Store getStore(Provider provider)
    throws NoSuchProviderException
  {
    return getStore(provider, null);
  }

  private Store getStore(Provider provider, URLName url)
    throws NoSuchProviderException
  {
    if ((provider == null) || (provider.getType() != Provider.Type.STORE))
      throw new NoSuchProviderException("invalid provider");

    try
    {
      return ((Store)getService(provider, url));
    } catch (ClassCastException cce) {
      throw new NoSuchProviderException("incorrect class");
    }
  }

  public Folder getFolder(URLName url)
    throws MessagingException
  {
    Store store = getStore(url);
    store.connect();
    return store.getFolder(url);
  }

  public Transport getTransport()
    throws NoSuchProviderException
  {
    return getTransport(getProperty("mail.transport.protocol"));
  }

  public Transport getTransport(String protocol)
    throws NoSuchProviderException
  {
    return getTransport(new URLName(protocol, null, -1, null, null, null));
  }

  public Transport getTransport(URLName url)
    throws NoSuchProviderException
  {
    String protocol = url.getProtocol();
    Provider p = getProvider(protocol);
    return getTransport(p, url);
  }

  public Transport getTransport(Provider provider)
    throws NoSuchProviderException
  {
    return getTransport(provider, null);
  }

  public Transport getTransport(Address address)
    throws NoSuchProviderException
  {
    String transportProtocol = (String)this.addressMap.get(address.getType());
    if (transportProtocol == null) {
      throw new NoSuchProviderException("No provider for Address type: " + address.getType());
    }

    return getTransport(transportProtocol);
  }

  private Transport getTransport(Provider provider, URLName url)
    throws NoSuchProviderException
  {
    if ((provider == null) || (provider.getType() != Provider.Type.TRANSPORT))
      throw new NoSuchProviderException("invalid provider");

    try
    {
      return ((Transport)getService(provider, url));
    } catch (ClassCastException cce) {
      throw new NoSuchProviderException("incorrect class");
    }
  }

  private Object getService(Provider provider, URLName url)
    throws NoSuchProviderException
  {
    ClassLoader cl;
    if (provider == null) {
      throw new NoSuchProviderException("null");
    }

    if (url == null) {
      url = new URLName(provider.getProtocol(), null, -1, null, null, null);
    }

    Object service = null;

    if (this.authenticator != null)
      cl = this.authenticator.getClass().getClassLoader();
    else {
      cl = super.getClass().getClassLoader();
    }

    Class serviceClass = null;
    try
    {
      ClassLoader ccl = getContextClassLoader();
      if (ccl != null)
        try {
          serviceClass = ccl.loadClass(provider.getClassName()); } catch (ClassNotFoundException ex) {
        }
      if (serviceClass == null)
        serviceClass = cl.loadClass(provider.getClassName());
    }
    catch (Exception ex1)
    {
      try
      {
        serviceClass = Class.forName(provider.getClassName());
      }
      catch (Exception ex) {
        if (this.debug) ex.printStackTrace(getDebugOut());
        throw new NoSuchProviderException(provider.getProtocol());
      }
    }

    try
    {
      Class[] c = { Session.class, URLName.class };
      Constructor cons = serviceClass.getConstructor(c);

      Object[] o = { this, url };
      service = cons.newInstance(o);
    }
    catch (Exception ex) {
      if (this.debug) ex.printStackTrace(getDebugOut());
      throw new NoSuchProviderException(provider.getProtocol());
    }

    return service;
  }

  public void setPasswordAuthentication(URLName url, PasswordAuthentication pw)
  {
    if (pw == null)
      this.authTable.remove(url);
    else
      this.authTable.put(url, pw);
  }

  public PasswordAuthentication getPasswordAuthentication(URLName url)
  {
    return ((PasswordAuthentication)this.authTable.get(url));
  }

  public PasswordAuthentication requestPasswordAuthentication(InetAddress addr, int port, String protocol, String prompt, String defaultUserName)
  {
    if (this.authenticator != null) {
      return this.authenticator.requestPasswordAuthentication(addr, port, protocol, prompt, defaultUserName);
    }

    return null;
  }

  public Properties getProperties()
  {
    return this.props;
  }

  public String getProperty(String name)
  {
    return this.props.getProperty(name);
  }

  private void loadProviders(Class cl)
  {
    StreamLoader loader = new StreamLoader() {
      public void load(InputStream is) throws IOException {
        Session.access$000(Session.this, is);
      }

    };
    try
    {
      String res = System.getProperty("java.home") + File.separator + "lib" + File.separator + "javamail.providers";

      loadFile(res, loader);
    } catch (SecurityException sex) {
      if (this.debug)
        pr("DEBUG: can't get java.home: " + sex);

    }

    loadAllResources("META-INF/javamail.providers", cl, loader);

    loadResource("/META-INF/javamail.default.providers", cl, loader);

    if (this.providers.size() == 0) {
      if (this.debug)
        pr("DEBUG: failed to load any providers, using defaults");

      addProvider(new Provider(Provider.Type.STORE, "imap", "com.sun.mail.imap.IMAPStore", "Sun Microsystems, Inc.", "1.4ea"));

      addProvider(new Provider(Provider.Type.STORE, "imaps", "com.sun.mail.imap.IMAPSSLStore", "Sun Microsystems, Inc.", "1.4ea"));

      addProvider(new Provider(Provider.Type.STORE, "pop3", "com.sun.mail.pop3.POP3Store", "Sun Microsystems, Inc.", "1.4ea"));

      addProvider(new Provider(Provider.Type.STORE, "pop3s", "com.sun.mail.pop3.POP3SSLStore", "Sun Microsystems, Inc.", "1.4ea"));

      addProvider(new Provider(Provider.Type.TRANSPORT, "smtp", "com.sun.mail.smtp.SMTPTransport", "Sun Microsystems, Inc.", "1.4ea"));

      addProvider(new Provider(Provider.Type.TRANSPORT, "smtps", "com.sun.mail.smtp.SMTPSSLTransport", "Sun Microsystems, Inc.", "1.4ea"));
    }

    if (this.debug)
    {
      pr("DEBUG: Tables of loaded providers");
      pr("DEBUG: Providers Listed By Class Name: " + this.providersByClassName.toString());

      pr("DEBUG: Providers Listed By Protocol: " + this.providersByProtocol.toString());
    }
  }

  private void loadProvidersFromStream(InputStream is)
    throws IOException
  {
    if (is != null) {
      LineInputStream lis = new LineInputStream(is);
      while (true) { Provider.Type type;
        String protocol;
        String className;
        String vendor;
        String version;
        while (true) { String currLine;
          do { while (true) { if ((currLine = lis.readLine()) == null) return;

              if (!(currLine.startsWith("#"))) break;
            }
            type = null;
            protocol = null; className = null;
            vendor = null; version = null;

            StringTokenizer tuples = new StringTokenizer(currLine, ";");
            while (tuples.hasMoreTokens()) {
              String currTuple = tuples.nextToken().trim();

              int sep = currTuple.indexOf("=");
              if (currTuple.startsWith("protocol=")) {
                protocol = currTuple.substring(sep + 1);
              } else if (currTuple.startsWith("type=")) {
                String strType = currTuple.substring(sep + 1);
                if (strType.equalsIgnoreCase("store"))
                  type = Provider.Type.STORE;
                else if (strType.equalsIgnoreCase("transport"))
                  type = Provider.Type.TRANSPORT;
              }
              else if (currTuple.startsWith("class=")) {
                className = currTuple.substring(sep + 1);
              } else if (currTuple.startsWith("vendor=")) {
                vendor = currTuple.substring(sep + 1);
              } else if (currTuple.startsWith("version=")) {
                version = currTuple.substring(sep + 1);
              }

            }

            if ((type != null) && (protocol != null) && (className != null) && (protocol.length() > 0) && (className.length() > 0))
              break label305;
          }
          while (!(this.debug));
          pr("DEBUG: Bad provider entry: " + currLine);
        }

        label305: Provider provider = new Provider(type, protocol, className, vendor, version);

        addProvider(provider);
      }
    }
  }

  public synchronized void addProvider(Provider provider)
  {
    this.providers.addElement(provider);
    this.providersByClassName.put(provider.getClassName(), provider);
    if (!(this.providersByProtocol.containsKey(provider.getProtocol())))
      this.providersByProtocol.put(provider.getProtocol(), provider);
  }

  private void loadAddressMap(Class cl)
  {
    StreamLoader loader = new StreamLoader() {
      public void load(InputStream is) throws IOException {
        Session.access$100(Session.this).load(is);
      }

    };
    loadResource("/META-INF/javamail.default.address.map", cl, loader);

    loadAllResources("META-INF/javamail.address.map", cl, loader);
    try
    {
      String res = System.getProperty("java.home") + File.separator + "lib" + File.separator + "javamail.address.map";

      loadFile(res, loader);
    } catch (SecurityException sex) {
      if (this.debug)
        pr("DEBUG: can't get java.home: " + sex);
    }

    if (this.addressMap.isEmpty()) {
      if (this.debug)
        pr("DEBUG: failed to load address map, using defaults");
      this.addressMap.put("rfc822", "smtp");
    }
  }

  public synchronized void setProtocolForAddress(String addresstype, String protocol)
  {
    if (protocol == null)
      this.addressMap.remove(addresstype);
    else
      this.addressMap.put(addresstype, protocol);
  }

  private void loadFile(String name, StreamLoader loader)
  {
    InputStream clis = null;
    try {
      clis = new BufferedInputStream(new FileInputStream(name));
      if (clis != null) {
        loader.load(clis);
        if (this.debug)
          pr("DEBUG: successfully loaded file: " + name);
      }
      else if (this.debug) {
        pr("DEBUG: not loading file: " + name);
      }
    } catch (IOException e) {
      if (this.debug)
        pr("DEBUG: " + e);
    } catch (SecurityException sex) {
      if (this.debug)
        pr("DEBUG: " + sex);
    } finally {
      try {
        if (clis != null)
          clis.close();
      }
      catch (IOException ex)
      {
      }
    }
  }

  private void loadResource(String name, Class cl, StreamLoader loader) {
    InputStream clis = null;
    try {
      clis = getResourceAsStream(cl, name);
      if (clis != null) {
        loader.load(clis);
        if (this.debug)
          pr("DEBUG: successfully loaded resource: " + name);
      }
      else if (this.debug) {
        pr("DEBUG: not loading resource: " + name);
      }
    } catch (IOException e) {
      if (this.debug)
        pr("DEBUG: " + e);
    } catch (SecurityException sex) {
      if (this.debug)
        pr("DEBUG: " + sex);
    } finally {
      try {
        if (clis != null)
          clis.close();
      }
      catch (IOException ex)
      {
      }
    }
  }

  private void loadAllResources(String name, Class cl, StreamLoader loader) {
    URL[] urls;
    int i;
    boolean anyLoaded = false;
    try
    {
      ClassLoader cld = null;

      cld = getContextClassLoader();
      if (cld == null)
        cld = cl.getClassLoader();
      if (cld != null)
        urls = getResources(cld, name);
      else
        urls = getSystemResources(name);
      if (urls != null)
        for (i = 0; i < urls.length; ++i) {
          URL url = urls[i];
          InputStream clis = null;
          if (this.debug)
            pr("DEBUG: URL " + url);
          try {
            clis = openStream(url);
            if (clis != null) {
              loader.load(clis);
              anyLoaded = true;
              if (this.debug)
                pr("DEBUG: successfully loaded resource: " + url);

            }
            else if (this.debug) {
              pr("DEBUG: not loading resource: " + url);
            }
          } catch (IOException ioex) {
            if (this.debug)
              pr("DEBUG: " + ioex);
          } catch (SecurityException sex) {
            if (this.debug)
              pr("DEBUG: " + sex);
          } finally {
            try {
              if (clis != null)
                clis.close();
            } catch (IOException cex) {
            }
          }
        }
    } catch (Exception ex) {
      if (this.debug)
        pr("DEBUG: " + ex);

    }

    if (!(anyLoaded)) {
      if (this.debug)
        pr("DEBUG: !anyLoaded");
      loadResource("/" + name, cl, loader);
    }
  }

  private void pr(String str) {
    getDebugOut().println(str);
  }

  private static ClassLoader getContextClassLoader()
  {
    return ((ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
    {
      public Object run() {
        ClassLoader cl = null;
        try {
          cl = Thread.currentThread().getContextClassLoader(); } catch (SecurityException ex) {
        }
        return cl;
      }
    }));
  }

  private static InputStream getResourceAsStream(Class c, String name) throws IOException
  {
    try {
      return ((InputStream)AccessController.doPrivileged(new PrivilegedExceptionAction(c, name) { private final Class val$c;
        private final String val$name;

        public Object run() throws IOException { return this.val$c.getResourceAsStream(this.val$name);
        } } ));
    }
    catch (PrivilegedActionException e) {
      throw ((IOException)e.getException());
    }
  }

  private static URL[] getResources(ClassLoader cl, String name) {
    return ((URL[])(URL[])AccessController.doPrivileged(new PrivilegedAction(cl, name) { private final ClassLoader val$cl;
      private final String val$name;

      public Object run() { URL[] ret = null;
        try {
          Vector v = new Vector();
          Enumeration e = this.val$cl.getResources(this.val$name);
          while ((e != null) && (e.hasMoreElements())) {
            URL url = (URL)e.nextElement();
            if (url != null)
              v.addElement(url);
          }
          if (v.size() > 0) {
            ret = new URL[v.size()];
            v.copyInto(ret); }
        } catch (IOException ioex) {
        } catch (SecurityException ex) {
        }
        return ret;
      }
    }));
  }

  private static URL[] getSystemResources(String name) {
    return ((URL[])(URL[])AccessController.doPrivileged(new PrivilegedAction(name) {
      private final String val$name;

      public Object run() { URL[] ret = null;
        try {
          Vector v = new Vector();
          Enumeration e = ClassLoader.getSystemResources(this.val$name);
          while ((e != null) && (e.hasMoreElements())) {
            URL url = (URL)e.nextElement();
            if (url != null)
              v.addElement(url);
          }
          if (v.size() > 0) {
            ret = new URL[v.size()];
            v.copyInto(ret); }
        } catch (IOException ioex) {
        } catch (SecurityException ex) {
        }
        return ret;
      }
    }));
  }

  private static InputStream openStream(URL url) throws IOException {
    try {
      return ((InputStream)AccessController.doPrivileged(new PrivilegedExceptionAction(url) {
        private final URL val$url;

        public Object run() throws IOException { return this.val$url.openStream();
        } } ));
    }
    catch (PrivilegedActionException e) {
      throw ((IOException)e.getException());
    }
  }

  static void access$000(Session x0, InputStream x1)
    throws IOException
  {
    x0.loadProvidersFromStream(x1); } 
  static Properties access$100(Session x0) { return x0.addressMap;
  }
}