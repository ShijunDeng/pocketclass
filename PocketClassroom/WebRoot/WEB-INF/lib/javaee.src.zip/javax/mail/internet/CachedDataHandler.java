package javax.mail.internet;

import javax.activation.DataHandler;

class CachedDataHandler extends DataHandler
{
  public CachedDataHandler(Object o, String mimeType)
  {
    super(o, mimeType);
  }
}