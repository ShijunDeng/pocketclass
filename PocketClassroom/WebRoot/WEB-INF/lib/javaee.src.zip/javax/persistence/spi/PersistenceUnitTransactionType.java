package javax.persistence.spi;

public enum PersistenceUnitTransactionType
{
  JTA, RESOURCE_LOCAL;

  public static final PersistenceUnitTransactionType[] values()
  {
    return ((PersistenceUnitTransactionType[])$VALUES.clone());
  }
}