package javax.persistence;

public enum TemporalType
{
  DATE, TIME, TIMESTAMP;

  public static final TemporalType[] values()
  {
    return ((TemporalType[])$VALUES.clone());
  }
}