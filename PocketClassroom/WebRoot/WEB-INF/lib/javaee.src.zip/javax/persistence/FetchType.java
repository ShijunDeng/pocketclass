package javax.persistence;

public enum FetchType
{
  LAZY, EAGER;

  public static final FetchType[] values()
  {
    return ((FetchType[])$VALUES.clone());
  }
}