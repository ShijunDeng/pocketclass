package javax.persistence;

public enum PersistenceContextType
{
  TRANSACTION, EXTENDED;

  public static final PersistenceContextType[] values()
  {
    return ((PersistenceContextType[])$VALUES.clone());
  }
}