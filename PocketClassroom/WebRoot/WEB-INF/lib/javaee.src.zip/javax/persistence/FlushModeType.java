package javax.persistence;

public enum FlushModeType
{
  COMMIT, AUTO;

  public static final FlushModeType[] values()
  {
    return ((FlushModeType[])$VALUES.clone());
  }
}