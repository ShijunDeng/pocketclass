package javax.persistence;

public enum InheritanceType
{
  SINGLE_TABLE, TABLE_PER_CLASS, JOINED;

  public static final InheritanceType[] values()
  {
    return ((InheritanceType[])$VALUES.clone());
  }
}