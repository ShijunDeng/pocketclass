package javax.persistence;

public enum GenerationType
{
  TABLE, SEQUENCE, IDENTITY, AUTO;

  public static final GenerationType[] values()
  {
    return ((GenerationType[])$VALUES.clone());
  }
}