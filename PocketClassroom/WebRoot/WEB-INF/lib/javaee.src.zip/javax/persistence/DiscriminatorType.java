package javax.persistence;

public enum DiscriminatorType
{
  STRING, CHAR, INTEGER;

  public static final DiscriminatorType[] values()
  {
    return ((DiscriminatorType[])$VALUES.clone());
  }
}