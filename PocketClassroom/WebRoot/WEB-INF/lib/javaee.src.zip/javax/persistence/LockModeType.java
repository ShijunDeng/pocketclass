package javax.persistence;

public enum LockModeType
{
  READ, WRITE;

  public static final LockModeType[] values()
  {
    return ((LockModeType[])$VALUES.clone());
  }
}