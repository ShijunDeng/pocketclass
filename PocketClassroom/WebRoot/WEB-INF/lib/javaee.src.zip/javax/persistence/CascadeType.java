package javax.persistence;

public enum CascadeType
{
  ALL, PERSIST, MERGE, REMOVE, REFRESH;

  public static final CascadeType[] values()
  {
    return ((CascadeType[])$VALUES.clone());
  }
}