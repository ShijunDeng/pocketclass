package javax.persistence;

public class NonUniqueResultException extends PersistenceException
{
  public NonUniqueResultException()
  {
  }

  public NonUniqueResultException(String message)
  {
    super(message);
  }
}