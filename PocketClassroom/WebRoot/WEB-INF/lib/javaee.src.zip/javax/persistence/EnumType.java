package javax.persistence;

public enum EnumType
{
  ORDINAL, STRING;

  public static final EnumType[] values()
  {
    return ((EnumType[])$VALUES.clone());
  }
}