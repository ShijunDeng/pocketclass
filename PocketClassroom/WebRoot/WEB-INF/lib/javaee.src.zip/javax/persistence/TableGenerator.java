package javax.persistence;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.TYPE, java.lang.annotation.ElementType.METHOD, java.lang.annotation.ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface TableGenerator
{
  public abstract String name();

  public abstract String table();

  public abstract String catalog();

  public abstract String schema();

  public abstract String pkColumnName();

  public abstract String valueColumnName();

  public abstract String pkColumnValue();

  public abstract int initialValue();

  public abstract int allocationSize();

  public abstract UniqueConstraint[] uniqueConstraints();
}