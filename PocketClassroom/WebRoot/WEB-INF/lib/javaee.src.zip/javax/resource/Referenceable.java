package javax.resource;

import javax.naming.Reference;

public abstract interface Referenceable extends javax.naming.Referenceable
{
  public abstract void setReference(Reference paramReference);
}