package javax.resource.cci;

public abstract interface ResourceAdapterMetaData
{
  public abstract String getAdapterVersion();

  public abstract String getAdapterVendorName();

  public abstract String getAdapterName();

  public abstract String getAdapterShortDescription();

  public abstract String getSpecVersion();

  public abstract String[] getInteractionSpecsSupported();

  public abstract boolean supportsExecuteWithInputAndOutputRecord();

  public abstract boolean supportsExecuteWithInputRecordOnly();

  public abstract boolean supportsLocalTransactionDemarcation();
}