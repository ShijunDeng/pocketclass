package javax.resource.cci;

import javax.resource.ResourceException;

public abstract interface MessageListener
{
  public abstract Record onMessage(Record paramRecord)
    throws ResourceException;
}