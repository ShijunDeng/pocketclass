package javax.resource.cci;

import java.io.Serializable;
import java.util.Map;

public abstract interface MappedRecord extends Record, Map, Serializable
{
}