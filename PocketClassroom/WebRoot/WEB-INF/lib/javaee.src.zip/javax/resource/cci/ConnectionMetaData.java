package javax.resource.cci;

import javax.resource.ResourceException;

public abstract interface ConnectionMetaData
{
  public abstract String getEISProductName()
    throws ResourceException;

  public abstract String getEISProductVersion()
    throws ResourceException;

  public abstract String getUserName()
    throws ResourceException;
}