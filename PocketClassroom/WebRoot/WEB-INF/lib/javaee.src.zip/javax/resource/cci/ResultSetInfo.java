package javax.resource.cci;

import javax.resource.ResourceException;

public abstract interface ResultSetInfo
{
  public abstract boolean updatesAreDetected(int paramInt)
    throws ResourceException;

  public abstract boolean insertsAreDetected(int paramInt)
    throws ResourceException;

  public abstract boolean deletesAreDetected(int paramInt)
    throws ResourceException;

  public abstract boolean supportsResultSetType(int paramInt)
    throws ResourceException;

  public abstract boolean supportsResultTypeConcurrency(int paramInt1, int paramInt2)
    throws ResourceException;

  public abstract boolean othersUpdatesAreVisible(int paramInt)
    throws ResourceException;

  public abstract boolean othersDeletesAreVisible(int paramInt)
    throws ResourceException;

  public abstract boolean othersInsertsAreVisible(int paramInt)
    throws ResourceException;

  public abstract boolean ownUpdatesAreVisible(int paramInt)
    throws ResourceException;

  public abstract boolean ownInsertsAreVisible(int paramInt)
    throws ResourceException;

  public abstract boolean ownDeletesAreVisible(int paramInt)
    throws ResourceException;
}