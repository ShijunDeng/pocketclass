package javax.resource.cci;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract interface Streamable
{
  public abstract void read(InputStream paramInputStream)
    throws IOException;

  public abstract void write(OutputStream paramOutputStream)
    throws IOException;
}