package javax.resource.cci;

import javax.resource.ResourceException;

public abstract interface LocalTransaction
{
  public abstract void begin()
    throws ResourceException;

  public abstract void commit()
    throws ResourceException;

  public abstract void rollback()
    throws ResourceException;
}