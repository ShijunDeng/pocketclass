package javax.resource.cci;

import java.io.Serializable;

public abstract interface Record extends Cloneable, Serializable
{
  public abstract String getRecordName();

  public abstract void setRecordName(String paramString);

  public abstract void setRecordShortDescription(String paramString);

  public abstract String getRecordShortDescription();

  public abstract boolean equals(Object paramObject);

  public abstract int hashCode();

  public abstract Object clone()
    throws CloneNotSupportedException;
}