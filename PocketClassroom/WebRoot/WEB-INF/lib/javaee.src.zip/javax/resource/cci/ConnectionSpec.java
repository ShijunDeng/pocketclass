package javax.resource.cci;

public abstract interface ConnectionSpec
{
}