package javax.resource.cci;

import java.io.Serializable;
import java.util.List;

public abstract interface IndexedRecord extends Record, List, Serializable
{
}