package javax.resource.cci;

import javax.resource.ResourceException;

public abstract interface Interaction
{
  public abstract void close()
    throws ResourceException;

  public abstract Connection getConnection();

  public abstract boolean execute(InteractionSpec paramInteractionSpec, Record paramRecord1, Record paramRecord2)
    throws ResourceException;

  public abstract Record execute(InteractionSpec paramInteractionSpec, Record paramRecord)
    throws ResourceException;

  public abstract ResourceWarning getWarnings()
    throws ResourceException;

  public abstract void clearWarnings()
    throws ResourceException;
}