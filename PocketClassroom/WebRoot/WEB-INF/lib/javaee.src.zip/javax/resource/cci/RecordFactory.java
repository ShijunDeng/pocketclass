package javax.resource.cci;

import javax.resource.ResourceException;

public abstract interface RecordFactory
{
  public abstract MappedRecord createMappedRecord(String paramString)
    throws ResourceException;

  public abstract IndexedRecord createIndexedRecord(String paramString)
    throws ResourceException;
}