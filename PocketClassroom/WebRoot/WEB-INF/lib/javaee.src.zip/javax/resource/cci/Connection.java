package javax.resource.cci;

import javax.resource.ResourceException;

public abstract interface Connection
{
  public abstract Interaction createInteraction()
    throws ResourceException;

  public abstract LocalTransaction getLocalTransaction()
    throws ResourceException;

  public abstract ConnectionMetaData getMetaData()
    throws ResourceException;

  public abstract ResultSetInfo getResultSetInfo()
    throws ResourceException;

  public abstract void close()
    throws ResourceException;
}