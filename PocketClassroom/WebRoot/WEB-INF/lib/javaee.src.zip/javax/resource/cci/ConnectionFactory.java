package javax.resource.cci;

import java.io.Serializable;
import javax.resource.Referenceable;
import javax.resource.ResourceException;

public abstract interface ConnectionFactory extends Serializable, Referenceable
{
  public abstract Connection getConnection()
    throws ResourceException;

  public abstract Connection getConnection(ConnectionSpec paramConnectionSpec)
    throws ResourceException;

  public abstract RecordFactory getRecordFactory()
    throws ResourceException;

  public abstract ResourceAdapterMetaData getMetaData()
    throws ResourceException;
}