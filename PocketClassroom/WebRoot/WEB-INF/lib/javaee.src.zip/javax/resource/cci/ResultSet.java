package javax.resource.cci;

public abstract interface ResultSet extends Record, java.sql.ResultSet
{
}