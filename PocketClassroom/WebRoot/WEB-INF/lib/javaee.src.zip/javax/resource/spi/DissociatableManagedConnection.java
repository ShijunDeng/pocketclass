package javax.resource.spi;

import javax.resource.ResourceException;

public abstract interface DissociatableManagedConnection
{
  public abstract void dissociateConnections()
    throws ResourceException;
}