package javax.resource.spi;

import java.util.EventListener;

public abstract interface ConnectionEventListener extends EventListener
{
  public abstract void connectionClosed(ConnectionEvent paramConnectionEvent);

  public abstract void localTransactionStarted(ConnectionEvent paramConnectionEvent);

  public abstract void localTransactionCommitted(ConnectionEvent paramConnectionEvent);

  public abstract void localTransactionRolledback(ConnectionEvent paramConnectionEvent);

  public abstract void connectionErrorOccurred(ConnectionEvent paramConnectionEvent);
}