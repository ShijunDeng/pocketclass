package javax.resource.spi.work;

public abstract interface Work extends Runnable
{
  public abstract void release();
}