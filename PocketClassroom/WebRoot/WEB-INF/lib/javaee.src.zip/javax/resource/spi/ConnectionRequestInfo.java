package javax.resource.spi;

public abstract interface ConnectionRequestInfo
{
  public abstract boolean equals(Object paramObject);

  public abstract int hashCode();
}