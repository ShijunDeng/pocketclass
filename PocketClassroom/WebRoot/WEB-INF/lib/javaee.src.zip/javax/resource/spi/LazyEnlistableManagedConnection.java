package javax.resource.spi;

public abstract interface LazyEnlistableManagedConnection
{
}