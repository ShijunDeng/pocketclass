package javax.resource.spi;

public abstract interface ActivationSpec extends ResourceAdapterAssociation
{
  public abstract void validate()
    throws InvalidPropertyException;
}