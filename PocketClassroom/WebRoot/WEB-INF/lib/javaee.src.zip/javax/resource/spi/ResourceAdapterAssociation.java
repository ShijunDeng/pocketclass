package javax.resource.spi;

import javax.resource.ResourceException;

public abstract interface ResourceAdapterAssociation
{
  public abstract ResourceAdapter getResourceAdapter();

  public abstract void setResourceAdapter(ResourceAdapter paramResourceAdapter)
    throws ResourceException;
}