package javax.resource.spi;

import javax.resource.ResourceException;

public abstract interface LazyAssociatableConnectionManager
{
  public abstract void associateConnection(Object paramObject, ManagedConnectionFactory paramManagedConnectionFactory, ConnectionRequestInfo paramConnectionRequestInfo)
    throws ResourceException;
}