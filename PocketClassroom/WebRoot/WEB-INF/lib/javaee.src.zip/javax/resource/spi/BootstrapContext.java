package javax.resource.spi;

import java.util.Timer;
import javax.resource.spi.work.WorkManager;

public abstract interface BootstrapContext
{
  public abstract WorkManager getWorkManager();

  public abstract XATerminator getXATerminator();

  public abstract Timer createTimer()
    throws UnavailableException;
}