package javax.resource.spi;

import java.util.Set;
import javax.resource.ResourceException;

public abstract interface ValidatingManagedConnectionFactory
{
  public abstract Set getInvalidConnections(Set paramSet)
    throws ResourceException;
}