package javax.resource.spi;

import javax.resource.ResourceException;

public abstract interface ManagedConnectionMetaData
{
  public abstract String getEISProductName()
    throws ResourceException;

  public abstract String getEISProductVersion()
    throws ResourceException;

  public abstract int getMaxConnections()
    throws ResourceException;

  public abstract String getUserName()
    throws ResourceException;
}