package javax.resource.spi;

import javax.resource.ResourceException;

public abstract interface LazyEnlistableConnectionManager
{
  public abstract void lazyEnlist(ManagedConnection paramManagedConnection)
    throws ResourceException;
}