package javax.resource.spi.endpoint;

import java.lang.reflect.Method;
import javax.resource.ResourceException;

public abstract interface MessageEndpoint
{
  public abstract void beforeDelivery(Method paramMethod)
    throws NoSuchMethodException, ResourceException;

  public abstract void afterDelivery()
    throws ResourceException;

  public abstract void release();
}