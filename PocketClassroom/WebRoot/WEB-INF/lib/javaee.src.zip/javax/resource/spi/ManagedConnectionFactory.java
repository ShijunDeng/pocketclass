package javax.resource.spi;

import java.io.PrintWriter;
import java.io.Serializable;
import java.util.Set;
import javax.resource.ResourceException;
import javax.security.auth.Subject;

public abstract interface ManagedConnectionFactory extends Serializable
{
  public abstract Object createConnectionFactory(ConnectionManager paramConnectionManager)
    throws ResourceException;

  public abstract Object createConnectionFactory()
    throws ResourceException;

  public abstract ManagedConnection createManagedConnection(Subject paramSubject, ConnectionRequestInfo paramConnectionRequestInfo)
    throws ResourceException;

  public abstract ManagedConnection matchManagedConnections(Set paramSet, Subject paramSubject, ConnectionRequestInfo paramConnectionRequestInfo)
    throws ResourceException;

  public abstract void setLogWriter(PrintWriter paramPrintWriter)
    throws ResourceException;

  public abstract PrintWriter getLogWriter()
    throws ResourceException;

  public abstract int hashCode();

  public abstract boolean equals(Object paramObject);
}