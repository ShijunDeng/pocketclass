package javax.resource.spi;

import javax.transaction.xa.XAException;
import javax.transaction.xa.Xid;

public abstract interface XATerminator
{
  public abstract void commit(Xid paramXid, boolean paramBoolean)
    throws XAException;

  public abstract void forget(Xid paramXid)
    throws XAException;

  public abstract int prepare(Xid paramXid)
    throws XAException;

  public abstract Xid[] recover(int paramInt)
    throws XAException;

  public abstract void rollback(Xid paramXid)
    throws XAException;
}