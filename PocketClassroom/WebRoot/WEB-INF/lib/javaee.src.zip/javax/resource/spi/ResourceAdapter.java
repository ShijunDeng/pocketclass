package javax.resource.spi;

import javax.resource.ResourceException;
import javax.resource.spi.endpoint.MessageEndpointFactory;
import javax.transaction.xa.XAResource;

public abstract interface ResourceAdapter
{
  public abstract void start(BootstrapContext paramBootstrapContext)
    throws ResourceAdapterInternalException;

  public abstract void stop();

  public abstract void endpointActivation(MessageEndpointFactory paramMessageEndpointFactory, ActivationSpec paramActivationSpec)
    throws ResourceException;

  public abstract void endpointDeactivation(MessageEndpointFactory paramMessageEndpointFactory, ActivationSpec paramActivationSpec);

  public abstract XAResource[] getXAResources(ActivationSpec[] paramArrayOfActivationSpec)
    throws ResourceException;
}