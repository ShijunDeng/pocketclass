package javax.resource.spi;

import java.io.PrintWriter;
import javax.resource.ResourceException;
import javax.security.auth.Subject;
import javax.transaction.xa.XAResource;

public abstract interface ManagedConnection
{
  public abstract Object getConnection(Subject paramSubject, ConnectionRequestInfo paramConnectionRequestInfo)
    throws ResourceException;

  public abstract void destroy()
    throws ResourceException;

  public abstract void cleanup()
    throws ResourceException;

  public abstract void associateConnection(Object paramObject)
    throws ResourceException;

  public abstract void addConnectionEventListener(ConnectionEventListener paramConnectionEventListener);

  public abstract void removeConnectionEventListener(ConnectionEventListener paramConnectionEventListener);

  public abstract XAResource getXAResource()
    throws ResourceException;

  public abstract LocalTransaction getLocalTransaction()
    throws ResourceException;

  public abstract ManagedConnectionMetaData getMetaData()
    throws ResourceException;

  public abstract void setLogWriter(PrintWriter paramPrintWriter)
    throws ResourceException;

  public abstract PrintWriter getLogWriter()
    throws ResourceException;
}