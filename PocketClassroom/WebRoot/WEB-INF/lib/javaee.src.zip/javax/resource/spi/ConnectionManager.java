package javax.resource.spi;

import java.io.Serializable;
import javax.resource.ResourceException;

public abstract interface ConnectionManager extends Serializable
{
  public abstract Object allocateConnection(ManagedConnectionFactory paramManagedConnectionFactory, ConnectionRequestInfo paramConnectionRequestInfo)
    throws ResourceException;
}