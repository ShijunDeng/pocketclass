package javax.resource.spi.security;

import javax.resource.spi.SecurityException;

/**
 * @deprecated
 */
public abstract interface GenericCredential
{
  public abstract String getName();

  public abstract String getMechType();

  public abstract byte[] getCredentialData()
    throws SecurityException;

  public abstract boolean equals(Object paramObject);

  public abstract int hashCode();
}