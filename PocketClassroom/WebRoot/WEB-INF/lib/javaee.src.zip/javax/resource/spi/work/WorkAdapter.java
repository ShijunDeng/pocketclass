package javax.resource.spi.work;

public class WorkAdapter
  implements WorkListener
{
  public void workAccepted(WorkEvent e)
  {
  }

  public void workRejected(WorkEvent e)
  {
  }

  public void workStarted(WorkEvent e)
  {
  }

  public void workCompleted(WorkEvent e)
  {
  }
}