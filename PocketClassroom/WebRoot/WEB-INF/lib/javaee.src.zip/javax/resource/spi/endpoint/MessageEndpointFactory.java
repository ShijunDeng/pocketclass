package javax.resource.spi.endpoint;

import java.lang.reflect.Method;
import javax.resource.spi.UnavailableException;
import javax.transaction.xa.XAResource;

public abstract interface MessageEndpointFactory
{
  public abstract MessageEndpoint createEndpoint(XAResource paramXAResource)
    throws UnavailableException;

  public abstract boolean isDeliveryTransacted(Method paramMethod)
    throws NoSuchMethodException;
}