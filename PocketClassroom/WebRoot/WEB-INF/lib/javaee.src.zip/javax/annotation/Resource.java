package javax.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.TYPE, java.lang.annotation.ElementType.FIELD, java.lang.annotation.ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Resource
{
  public abstract String name();

  public abstract Class type();

  public abstract AuthenticationType authenticationType();

  public abstract boolean shareable();

  public abstract String mappedName();

  public abstract String description();

  public static enum AuthenticationType
  {
    CONTAINER, APPLICATION;

    public static final AuthenticationType[] values()
    {
      return ((AuthenticationType[])$VALUES.clone());
    }
  }
}