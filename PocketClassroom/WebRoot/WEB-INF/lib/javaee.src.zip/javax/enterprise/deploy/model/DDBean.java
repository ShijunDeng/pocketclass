package javax.enterprise.deploy.model;

public abstract interface DDBean
{
  public abstract String getXpath();

  public abstract String getText();

  public abstract String getId();

  public abstract DDBeanRoot getRoot();

  public abstract DDBean[] getChildBean(String paramString);

  public abstract String[] getText(String paramString);

  public abstract void addXpathListener(String paramString, XpathListener paramXpathListener);

  public abstract void removeXpathListener(String paramString, XpathListener paramXpathListener);

  public abstract String[] getAttributeNames();

  public abstract String getAttributeValue(String paramString);
}