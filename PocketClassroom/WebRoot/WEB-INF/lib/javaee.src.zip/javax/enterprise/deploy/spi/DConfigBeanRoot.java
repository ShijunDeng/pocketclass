package javax.enterprise.deploy.spi;

import javax.enterprise.deploy.model.DDBeanRoot;

public abstract interface DConfigBeanRoot extends DConfigBean
{
  public abstract DConfigBean getDConfigBean(DDBeanRoot paramDDBeanRoot);
}