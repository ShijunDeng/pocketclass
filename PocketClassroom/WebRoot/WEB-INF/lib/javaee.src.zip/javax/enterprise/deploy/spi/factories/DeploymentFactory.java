package javax.enterprise.deploy.spi.factories;

import javax.enterprise.deploy.spi.DeploymentManager;
import javax.enterprise.deploy.spi.exceptions.DeploymentManagerCreationException;

public abstract interface DeploymentFactory
{
  public abstract boolean handlesURI(String paramString);

  public abstract DeploymentManager getDeploymentManager(String paramString1, String paramString2, String paramString3)
    throws DeploymentManagerCreationException;

  public abstract DeploymentManager getDisconnectedDeploymentManager(String paramString)
    throws DeploymentManagerCreationException;

  public abstract String getDisplayName();

  public abstract String getProductVersion();
}