package javax.enterprise.deploy.spi;

import java.beans.PropertyChangeListener;
import javax.enterprise.deploy.model.DDBean;
import javax.enterprise.deploy.model.XpathEvent;
import javax.enterprise.deploy.spi.exceptions.BeanNotFoundException;
import javax.enterprise.deploy.spi.exceptions.ConfigurationException;

public abstract interface DConfigBean
{
  public abstract DDBean getDDBean();

  public abstract String[] getXpaths();

  public abstract DConfigBean getDConfigBean(DDBean paramDDBean)
    throws ConfigurationException;

  public abstract void removeDConfigBean(DConfigBean paramDConfigBean)
    throws BeanNotFoundException;

  public abstract void notifyDDChange(XpathEvent paramXpathEvent);

  public abstract void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);

  public abstract void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
}