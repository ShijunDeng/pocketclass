package javax.enterprise.deploy.spi.exceptions;

public class DConfigBeanVersionUnsupportedException extends Exception
{
  public DConfigBeanVersionUnsupportedException(String s)
  {
    super(s);
  }
}