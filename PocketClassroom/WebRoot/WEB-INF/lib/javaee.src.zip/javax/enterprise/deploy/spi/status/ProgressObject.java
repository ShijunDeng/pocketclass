package javax.enterprise.deploy.spi.status;

import javax.enterprise.deploy.spi.TargetModuleID;
import javax.enterprise.deploy.spi.exceptions.OperationUnsupportedException;

public abstract interface ProgressObject
{
  public abstract DeploymentStatus getDeploymentStatus();

  public abstract TargetModuleID[] getResultTargetModuleIDs();

  public abstract ClientConfiguration getClientConfiguration(TargetModuleID paramTargetModuleID);

  public abstract boolean isCancelSupported();

  public abstract void cancel()
    throws OperationUnsupportedException;

  public abstract boolean isStopSupported();

  public abstract void stop()
    throws OperationUnsupportedException;

  public abstract void addProgressListener(ProgressListener paramProgressListener);

  public abstract void removeProgressListener(ProgressListener paramProgressListener);
}