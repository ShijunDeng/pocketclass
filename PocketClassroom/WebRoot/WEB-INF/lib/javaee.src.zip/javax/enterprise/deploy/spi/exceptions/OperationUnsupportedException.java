package javax.enterprise.deploy.spi.exceptions;

public class OperationUnsupportedException extends Exception
{
  public OperationUnsupportedException(String s)
  {
    super(s);
  }
}