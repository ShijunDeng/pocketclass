package javax.enterprise.deploy.model;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Enumeration;
import javax.enterprise.deploy.model.exceptions.DDBeanCreateException;
import javax.enterprise.deploy.shared.ModuleType;

public abstract interface DeployableObject
{
  public abstract ModuleType getType();

  public abstract DDBeanRoot getDDBeanRoot();

  public abstract DDBean[] getChildBean(String paramString);

  public abstract String[] getText(String paramString);

  public abstract Class getClassFromScope(String paramString);

  /**
   * @deprecated
   */
  public abstract String getModuleDTDVersion();

  public abstract DDBeanRoot getDDBeanRoot(String paramString)
    throws FileNotFoundException, DDBeanCreateException;

  public abstract Enumeration entries();

  public abstract InputStream getEntry(String paramString);
}