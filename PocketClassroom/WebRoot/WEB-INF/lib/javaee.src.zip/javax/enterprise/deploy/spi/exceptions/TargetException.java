package javax.enterprise.deploy.spi.exceptions;

public class TargetException extends Exception
{
  public TargetException(String s)
  {
    super(s);
  }
}