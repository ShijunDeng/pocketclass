package javax.enterprise.deploy.spi.exceptions;

public class ClientExecuteException extends Exception
{
  public ClientExecuteException()
  {
  }

  public ClientExecuteException(String msg)
  {
    super(msg);
  }
}