package javax.enterprise.deploy.spi;

import java.io.InputStream;
import java.io.OutputStream;
import javax.enterprise.deploy.model.DDBeanRoot;
import javax.enterprise.deploy.model.DeployableObject;
import javax.enterprise.deploy.spi.exceptions.BeanNotFoundException;
import javax.enterprise.deploy.spi.exceptions.ConfigurationException;

public abstract interface DeploymentConfiguration
{
  public abstract DeployableObject getDeployableObject();

  public abstract DConfigBeanRoot getDConfigBeanRoot(DDBeanRoot paramDDBeanRoot)
    throws ConfigurationException;

  public abstract void removeDConfigBean(DConfigBeanRoot paramDConfigBeanRoot)
    throws BeanNotFoundException;

  public abstract DConfigBeanRoot restoreDConfigBean(InputStream paramInputStream, DDBeanRoot paramDDBeanRoot)
    throws ConfigurationException;

  public abstract void saveDConfigBean(OutputStream paramOutputStream, DConfigBeanRoot paramDConfigBeanRoot)
    throws ConfigurationException;

  public abstract void restore(InputStream paramInputStream)
    throws ConfigurationException;

  public abstract void save(OutputStream paramOutputStream)
    throws ConfigurationException;
}